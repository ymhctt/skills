---
name: mes_project_skill
description: MES项目服务总结报告/项目进展分析生成技能。基于MES系统的报工数据、服务请求、合同子项等信息，自动生成客户项目服务总结报告HTML或项目进展分析报告。适用于项目验收、阶段性汇报、客户交付、项目进展跟踪等场景。
---

# MES项目服务总结/进展分析技能

## 功能说明

基于MES系统数据自动生成专业的项目报告，支持两种模式：

**模式A：服务总结报告**（适用于项目验收/阶段性汇报）
- 合同执行情况（合同子项、工时消耗）
- 服务人天分类分析（饼图+柱状图）
- 完整服务清单明细（真实报工数据）
- 交付文档清单
- 交付团队与工时分布
- 故障处理成果
- 交付价值总结

**模式B：项目进展分析**（适用于项目进行中/进度跟踪）
- 项目概览与KPI速览
- 执行团队与分工
- 服务请求明细与状态
- 报工详情与时间线
- ⚠️ 风险点分析（从报工remark中提取）
- 🎯 下一步建议

## 数据来源

### 1. 服务请求数据

**⚠️ 不要按标题关键词搜索！会遗漏大量数据。**

正确的查询方式（按优先级）：

```bash
# 方式1（推荐）：按公司ID+时间范围查询（最全面）
mes -o json service request list --company-id {公司ID} --start-time "{开始时间}" --end-time "{结束时间}" --page-size 200 > /tmp/requests.json

# 方式2：按合同子项关联查询（如果知道 acc-id）
# 先获取合同子项
mes -o json contract list-items --contract-id {合同ID} --page-size 50 > /tmp/contract_items.json
# 从子项中提取 accId，再通过 statistics list 关联查询
mes -o json statistics list --acc-id {子项ID} --from {开始日期} --to {结束日期} --page-size 1000 > /tmp/work_records.json

# 方式3：仅当公司名非常独特时，才用标题关键词辅助搜索
mes -o json service request list --title "{公司名关键词}" --page-size 100 > /tmp/requests.json
```

**查询策略：**
1. 先从 `contract list` 找到目标合同，获取 `companyId` 和合同ID
2. 用 `--company-id` + 时间范围查询服务请求（方式1）
3. 用 `contract list-items` 获取合同子项，再用 `statistics list --acc-id` 查询报工（方式2）

### 2. 报工记录数据

**⚠️ 报工数据必须准确！禁止混入无关项目的工时！**

正确的查询方式（按优先级）：

```bash
# 方式1（推荐，最准确）：按合同子项acc-id查询（只统计该子项的报工）
mes -o json statistics list --acc-id {子项ID} --from {开始日期} --to {结束日期} --page-size 1000 > /tmp/work_records.json

# 方式2（汇总多个子项）：先获取所有子项，再逐个查询后合并
mes -o json contract list-items --contract-id {合同ID} --page-size 50 > /tmp/contract_items.json
# 从合同子项中提取所有 accId，然后逐个查询：
mes -o json statistics list --acc-id {子项ID1} --from ... --to ... --page-size 1000 > /tmp/work_1.json
mes -o json statistics list --acc-id {子项ID2} --from ... --to ... --page-size 1000 > /tmp/work_2.json
# 合并去重（根据id字段）后统计

# 方式3（仅当确认该客户只有一个项目时）：按公司ID查询
mes -o json statistics list --from {开始日期} --to {结束日期} --company-id {公司ID} --page-size 1000 > /tmp/work_records.json
```

**⚠️ 关键校验规则：**
1. **必须使用 `--acc-id` 查询报工**，禁止只用 `--company-id`（会混入该客户其他项目的工时）
2. **报工记录的 executorName 字段必须非空**，为空说明查询方式有误
3. **每条报工必须属于目标合同子项**，通过 accId 字段验证
4. **多个子项需合并去重**，根据报工记录的 id 字段去重后再统计
5. **统计前必须抽查备注内容**，确认与目标项目相关（如包含项目关键词）
6. **如果发现工时异常（过高/过低）**，必须回溯原始数据验证

### 3. 合同数据
```bash
mes -o json contract list
```

### 4. 合同子项数据
从服务请求中提取 `accId` 和 `accName` 字段。

## 执行流程

### Step 1: 确定项目与公司ID
```bash
mes -o json contract list
# 搜索项目关键词，找到 companyId
```

### Step 2: 查询服务请求和报工记录

```bash
# ① 按公司ID+时间范围查询服务请求（推荐，数据最全）
mes -o json service request list --company-id {公司ID} --start-time "2026-01-01 00:00:00" --end-time "2026-12-31 23:59:59" --page-size 200 > /tmp/requests.json

# ② 按公司ID+时间范围查询报工记录
mes -o json statistics list --from 2026-01-01 --to 2026-12-31 --company-id {公司ID} --page-size 1000 > /tmp/work_records.json

# ③（可选）按合同子项关联查询，获取更精确的报工数据
mes -o json contract list-items --contract-id {合同ID} --page-size 50 > /tmp/contract_items.json
# 从合同子项中提取 accId，然后：
mes -o json statistics list --acc-id {子项ID} --from 2026-01-01 --to 2026-12-31 --page-size 1000 > /tmp/work_records_by_item.json
```

**⚠️ 关键要点：**
- **不要用 `--title` 关键词搜索服务请求**，会遗漏大量未包含关键词但实际关联该项目的工单
- **必须用 `--company-id` + 时间范围** 查询服务请求，这是最准确的方式
- **报工记录必须用 `--acc-id` 查询**，禁止只用 `--company-id`（会混入该客户其他项目工时）
- 如果服务请求数据量大（超过 page-size 限制），需要分页多次查询

### Step 3: 查询报工记录（必须用 acc-id）

```bash
# ① 从 Step 2 的服务请求中提取所有唯一的 accId
# ② 逐个查询每个子项的报工记录
mes -o json statistics list --acc-id {子项ID1} --from 2026-01-01 --to 2026-12-31 --page-size 1000 > /tmp/work_1.json
mes -o json statistics list --acc-id {子项ID2} --from 2026-01-01 --to 2026-12-31 --page-size 1000 > /tmp/work_2.json

# ③ 合并去重（根据 id 字段），再按 executorName 统计工时
```

### Step 4: 数据分析

**⚠️ 进展分析核心原则：必须综合三类数据交叉分析，不可只看子项完成率！**

1. **按合同/子项分类**（accId/accName）
2. **按服务类型分类**（故障处理、巡检、安装部署等）
3. **统计真实工时消耗**（taskTime字段）
4. **提取报工内容**（remark字段）— **逐条阅读，提取关键里程碑**
5. **阅读服务请求内容**（title、typeLabel、status）— 判断项目阶段
6. **按人员统计工时分布**
7. **交叉分析项目进展**：
   - 从报工 remark 中提取实际完成的工作（如"迁移完成"、"切换上线"、"DG搭建完成"等）
   - 从服务请求 title 和状态判断当前活跃任务
   - 结合合同子项完成率判断整体进度
   - 识别关键里程碑（如"数据迁移完成并切换上线"）
8. **识别项目进展、风险点**

## 项目阶段参考（一体机项目标准流程）

**项目进展必须基于实际报工内容和服务请求内容来判断，参照以下标准阶段：**

| 阶段 | 典型工作内容 | 报工关键词 |
|---|---|---|
| **工勘调研** | 硬件盘点、确认架构类型、确认存储网络类型、软件物料确认 | "盘点"、"调研"、"确认"、"硬件"、"架构" |
| **项目启动会** | 项目启动会材料编写、与客户对齐项目交付标准交付内容、交付边界 | "启动会"、"对齐"、"交付标准" |
| **方案规划** | IP地址规划、网络拓扑设计、端口矩阵确认、服务器机柜、操作系统版本、一体机软件容量等规划设计 | "规划"、"拓扑"、"IP"、"方案" |
| **设备上架** | 服务器上架、布线、IB卡/RoCE卡安装、BIOS参数设置、RAID配置、BMC地址配置 | "上架"、"布线"、"IB卡"、"RoCE"、"BIOS"、"RAID"、"BMC" |
| **操作系统安装** | 存储交换机配置 | "操作系统"、"安装"、"存储交换机" |
| **管理平台部署** | 部署监控节点、创建机柜信息、纳管交换机 | "监控"、"纳管"、"管理平台" |
| **融合节点部署** | 部署融合节点、申请许可证、初始化存储集群 | "融合节点"、"许可证"、"存储集群"、"初始化" |
| **数据库安装** | 安装数据库软件、配置数据库实例 | "数据库"、"安装"、"实例"、"配置" |
| **性能测试** | IO性能测试、数据库性能测试、高可用测试 | "性能测试"、"FIO"、"TPMCC"、"高可用" |
| **归档提交** | 测试报告、一体机巡检、档案提交 | "测试报告"、"巡检"、"档案" |
| **正式上线** | 正式上线 | "上线"、"切换"、"割接" |
| **数据迁移** | 如有迁移服务则提前迁移方案、保障方案 | "迁移"、"切换上线"、"割接"、"同步" |
| **使用培训** | 使用培训 | "培训" |
| **项目验收** | 项目验收材料准备 | "验收"、"验收材料" |
| **维保服务** | 故障处理、巡检、性能优化、咨询支持 | "故障"、"巡检"、"优化"、"咨询"、"SPA" |

**进展判断规则：**
- 报工内容中出现"切换上线"、"迁移完成" → 项目已进入**生产运行/维保阶段**
- 报工内容中出现"SPA"、"性能分析"（迁移场景） → **迁移上线后的性能验证**，非独立阶段
- 报工内容中出现"部署"、"安装" → **实施阶段**
- 报工内容中出现"测试"、"FIO"、"TPMCC" → **测试阶段**
- 服务请求全部已关闭且最近报工为日常优化 → **维保阶段**
- 不可仅根据子项完成率判断进展，必须结合实际工作内容

### Step 5: 生成HTML报告
使用模板生成报告。根据项目阶段选择模式：
- **模式A（服务总结）** → 使用 `template.html`
- **模式B（进展分析）** → 使用 `template_progress.html`

### Step 6: 展示结果（必须执行）

**⚠️ 每次生成报告后，必须同时展示以下两项内容（不自动发送）：**

1. **HTML报告** — 使用 `preview_url` 打开 `/tmp/mes_project_progress_report.html`
2. **企业微信消息内容** — 按标准格式输出完整markdown消息文本，供用户审阅

**⚠️ 不自动发送企业微信！等用户确认并给出webhook URL后再发送。**

### Step 7: 企业微信推送（用户确认后执行）

用户明确给出webhook URL并确认发送后，才执行此步骤。

**Webhook Markdown 消息标准格式**（必须严格按此格式发送）：

```
【{PROJECT_NAME} - 最新进展】（{YYYY-MM-DD}）

📋 项目概览
• 客户：{CLIENT_NAME}
• 目标：{PROJECT_GOAL}
• 启动时间：{START_DATE}
• 当前状态：{STATUS}

👥 执行团队
• {NAME}（{TEAM}）：{TASKS} | 报工{HOURS}h

📊 KPI速览
• 服务请求：{TICKET_COUNT}个（已关闭{CLOSED_COUNT}个）
• 总报工工时：{TOTAL_HOURS}h
• 客户对接人：{CONTACT}

⚠️ 核心风险点
🔴 高风险：{RISK_1}
🔴 高风险：{RISK_2}
🟡 中风险：{RISK_3}
🟡 中风险：{RISK_4}
🟡 中风险：{RISK_5}

🎯 下一步建议
• {STEP_1}
• {STEP_2}
• {STEP_3}
```

**发送命令示例**：

```bash
curl -s -X POST '{WEBHOOK_URL}' \
  -H 'Content-Type: application/json' \
  -d '{
  "msgtype": "markdown",
  "markdown": {
    "content": "【{PROJECT_NAME} - 最新进展】（{YYYY-MM-DD}）\n\n📋 项目概览\n• 客户：{CLIENT_NAME}\n• 目标：{PROJECT_GOAL}\n• 启动时间：{START_DATE}\n• 当前状态：{STATUS}\n\n👥 执行团队\n• {NAME}（{TEAM}）：{TASKS} | 报工{HOURS}h\n\n📊 KPI速览\n• 服务请求：{TICKET_COUNT}个（已关闭{CLOSED_COUNT}个）\n• 总报工工时：{TOTAL_HOURS}h\n• 客户对接人：{CONTACT}\n\n⚠️ 核心风险点\n🔴 高风险：{RISK_1}\n🔴 高风险：{RISK_2}\n🟡 中风险：{RISK_3}\n🟡 中风险：{RISK_4}\n🟡 中风险：{RISK_5}\n\n🎯 下一步建议\n• {STEP_1}\n• {STEP_2}\n• {STEP_3}"
  }
}'
```

**关键要求**：
- 必须使用 `msgtype: "markdown"` 格式
- 标题格式：【项目简称 - 最新进展】（日期）
- 使用 • 符号做列表，不用 - 或 *
- 风险点分🔴高风险和🟡中风险两级
- 执行团队列出所有参与人员及报工工时
- KPI速览包含服务请求数、总报工工时、客户对接人

## 企业微信 Webhook

### 发送流程
1. 生成报告后，使用 preview_url 展示HTML报告
2. 按标准格式输出企业微信消息内容（不发送）
3. 询问用户是否推送及webhook URL
4. 用户确认后再通过 webhook 发送

## 报告模板

### 模式A模板（template.html）- 服务总结报告
适用于项目验收/阶段性总结：
1. 📋 服务报告概述
2. 📑 合同执行情况（合同子项+进度条）
3. 📈 服务人天分类分析（Chart.js图表）
4. 📄 交付文档清单
5. 📋 服务清单明细（真实报工数据）
6. 👥 交付团队与工时分布
7. 🔧 部分故障处理成果
8. 🏆 服务结论 - 交付价值总结

### 模式B模板（template_progress.html）- 项目进展分析
适用于项目进行中/进度跟踪：
1. 📋 项目概览
2. KPI速览卡片
3. 👥 执行团队与分工
4. 📄 服务请求明细
5. ⏱️ 报工详情
6. 📅 实施进度时间线
7. ⚠️ 当前风险点（从remark提取）
8. 🎯 下一步建议

## 样式规范

采用深蓝色主题（#1a237e / #283593）：
- 渐变Header
- 粘性导航栏（模式A）
- KPI汇总卡片（5种渐变色）
- Chart.js交互式图表（模式A）
- 响应式布局

## 注意事项

1. 报工数据必须从MES系统真实获取，不可估算
2. 服务内容使用报工remark字段，AI总结提炼
3. 工时统计使用taskTime字段（小时）
4. 合同子项从服务请求的accId/accName提取
5. 交付文档从报工内容中识别（巡检报告、PPT、方案等）
6. 风险点从报工remark中提取关键词（如"缓慢"、"阻塞"、"错误"、"异常"、"无法"等）
7. **企业微信推送必须征得用户确认，不可自动发送**
8. **每次必须展示HTML报告和企微消息内容，不自动发送**
9. **项目进展判断必须基于报工内容和服务请求内容交叉分析，参照一体机标准阶段判断**
10. **⚠️ 查询服务请求和报工时，必须用 `--company-id` + 时间范围，禁止用 `--title` 关键词搜索，会遗漏大量数据**
11. **⚠️ 报工数据必须用 `--acc-id` 按合同子项查询，禁止只用 `--company-id`，会混入该客户其他项目的工时**
12. **⚠️ 统计前必须校验数据：executorName 非空、accId 匹配目标子项、抽查 remark 确认项目相关性**

## 文件清单

```
mes_project_skill/
├── SKILL.md                  # 技能说明文档
├── template.html             # 模式A：服务总结报告模板
└── template_progress.html    # 模式B：项目进展分析模板
```
