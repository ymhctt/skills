# Design Systems

[English](README.md) | [中文](README.zh-CN.md)

All design system files are sourced from the [`design-systems`](https://github.com/nexu-io/open-design/tree/main/design-systems) directory of the [open-design](https://github.com/nexu-io/open-design) project.

Each subfolder is a portable design system in `DESIGN.md` format.

## Design System Skills

150+ self-contained skill folders for generating HTML/Markdown from design system specifications.

Each skill is **fully standalone** — copy the folder anywhere to use it independently.

### Skill Structure

```
skills/<slug>/
├── SKILL.md           ← Main skill file (DESIGN.md embedded)
├── examples/          ← Example outputs
│   ├── example.html   ← HTML example
│   └── example.md     ← Markdown example
└── references/        ← Original source files
    ├── DESIGN.md      ← Design specification
    └── tokens.css     ← CSS tokens (if available)
```

### Usage

**Create a landing page:**
```
/design-stripe Create a hero section with CTA button
```

**Generate a component:**
```
/design-apple Build a pricing card component
```

**Document the color palette:**
```
/design-figma List all colors in a markdown table
```

### Regenerating Skills

```bash
# Regenerate SKILL.md files (use --force to overwrite)
node --experimental-strip-types scripts/generate-skills.ts --force

# Regenerate example files
node --experimental-strip-types scripts/generate-examples.ts --force

# Reorganize references directory
node --experimental-strip-types scripts/reorganize-skills.ts
```