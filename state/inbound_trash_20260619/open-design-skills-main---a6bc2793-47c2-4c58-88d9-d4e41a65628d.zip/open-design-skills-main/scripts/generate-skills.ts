#!/usr/bin/env node --experimental-strip-types

/**
 * Batch generate standalone design system skills from DESIGN.md files.
 *
 * Usage:
 *   node --experimental-strip-types skills/generate-skills.ts [--force]
 *
 * Each skill is fully self-contained — DESIGN.md content is embedded
 * directly into SKILL.md so skills can be copied anywhere independently.
 */

import { readdir, readFile, writeFile, mkdir } from "fs/promises";
import { join } from "path";

const DESIGN_ROOT = join(import.meta.dirname, "..", "design-systems");
const SKILLS_DIR = join(import.meta.dirname, "..", "skills");
const FORCE = process.argv.includes("--force");

interface DesignSystemInfo {
  slug: string;
  name: string;
  category: string;
  description: string;
  designContent: string;
}

async function getDesignSystems(): Promise<DesignSystemInfo[]> {
  const entries = await readdir(DESIGN_ROOT, { withFileTypes: true });
  const systems: DesignSystemInfo[] = [];

  for (const entry of entries) {
    if (!entry.isDirectory() || entry.name.startsWith(".") || entry.name === "skills") continue;

    const designPath = join(DESIGN_ROOT, entry.name, "DESIGN.md");
    try {
      const content = await readFile(designPath, "utf-8");
      const lines = content.split("\n");

      // Extract H1 title
      const h1Line = lines.find((l) => l.startsWith("# "));
      const rawTitle = h1Line?.replace(/^#\s+/, "") ?? entry.name;

      // Strip "Design System Inspired by " prefix
      const name = rawTitle.replace(/^Design System Inspired by\s+/i, "").trim() || entry.name;

      // Extract category from "> Category: X" line
      const categoryLine = lines.find((l) => l.startsWith("> Category:"));
      const category = categoryLine?.replace(/^>\s*Category:\s*/, "").trim() ?? "";

      // Extract description (line after category)
      const categoryIdx = lines.indexOf(categoryLine ?? "");
      const description = lines[categoryIdx + 1]?.replace(/^>\s*/, "").trim() ?? "";

      systems.push({
        slug: entry.name,
        name,
        category,
        description,
        designContent: content,
      });
    } catch {
      // No DESIGN.md, skip
    }
  }

  return systems;
}

function generateSkillMd(info: DesignSystemInfo): string {
  return `---
name: design-${info.slug}
description: "Generate HTML or Markdown using the ${info.name} design system. TRIGGER when: user mentions ${info.slug}, ${info.name}, or asks to create UI/content with this design style. Also trigger for requests like 'design a page in ${info.slug} style' or 'use ${info.name} design tokens'."
---

# ${info.name} Design System

You are a design implementation agent. Your job is to generate production-ready HTML or polished Markdown that faithfully applies the **${info.name}** design system.

## Design System Specification

${info.designContent}

## Output Modes

### HTML Output (default for UI requests)
When the user asks for a page, component, landing page, dashboard, or any visual artifact:

1. Use the design specification above
2. Generate a single self-contained HTML file with:
   - All CSS in a \`<style>\` block using CSS custom properties from the design system
   - \`:\` root block with all color/typography tokens
   - Semantic HTML5 structure
   - Responsive layout
   - No external dependencies (fonts loaded via Google Fonts or system stacks)

### Markdown Output (default for documentation requests)
When the user asks for documentation, specs, or text content:

1. Use the design specification above
2. Generate Markdown that reflects the design system's:
   - Color references in code blocks
   - Typography specifications in tables
   - Component patterns as structured documentation

## Token Mapping

Standard CSS variable names to use:
- \`--bg\` → background
- \`--surface\` → card/elevated surfaces
- \`--fg\` → primary text
- \`--muted\` → secondary text
- \`--border\` → borders and dividers
- \`--accent\` → primary interactive color
- \`--success\`, \`--warn\`, \`--danger\` → semantic colors
- \`--font-display\` → headings
- \`--font-body\` → body text
- \`--font-mono\` → code/technical

## Quality Checks

Before outputting, verify:
- [ ] All colors reference the design system's palette (no invented colors)
- [ ] Typography uses specified font families
- [ ] Spacing follows the design system's scale
- [ ] Component styles match the documented patterns
- [ ] No patterns from the "Don't" section appear

## Example Usage

User: "Create a landing page hero section"
→ Generate HTML with hero using the system's color palette, typography, and spacing

User: "Document the color palette"
→ Generate Markdown table with all colors, hex values, and usage notes

User: "Build a pricing card component"
→ Generate HTML card component matching the system's card styling pattern
`;
}

async function main() {
  const systems = await getDesignSystems();

  console.log(`Found ${systems.length} design systems`);

  let created = 0;
  let skipped = 0;

  for (const system of systems) {
    const skillDir = join(SKILLS_DIR, system.slug);
    const skillPath = join(skillDir, "SKILL.md");

    try {
      if (!FORCE) {
        await readFile(skillPath, "utf-8");
        skipped++;
        continue;
      }
    } catch {
      // Doesn't exist, create it
    }

    await mkdir(skillDir, { recursive: true });
    const content = generateSkillMd(system);
    await writeFile(skillPath, content, "utf-8");
    created++;
  }

  console.log(`Created: ${created}, Skipped: ${skipped}`);
  console.log(`Skills directory: ${SKILLS_DIR}`);
}

main().catch(console.error);
