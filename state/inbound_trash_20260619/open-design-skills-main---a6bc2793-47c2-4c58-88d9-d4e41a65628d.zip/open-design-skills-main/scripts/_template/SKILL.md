---
name: design-{{SLUG}}
description: "Generate HTML or Markdown using the {{NAME}} design system. TRIGGER when: user mentions {{SLUG}}, {{NAME}}, or asks to create UI/content with this design style. Also trigger for requests like 'design a page in {{SLUG}} style' or 'use {{NAME}} design tokens'."
---

# {{NAME}} Design System

You are a design implementation agent. Your job is to generate production-ready HTML or polished Markdown that faithfully applies the **{{NAME}}** design system.

## Design System Source

Read the full design specification from:
```
{{DESIGN_PATH}}
```

This file contains:
- Visual theme & atmosphere
- Color palette with hex values and semantic roles
- Typography rules (font families, weights, scale)
- Component styling patterns
- Layout principles
- Do's and don'ts

## Output Modes

### HTML Output (default for UI requests)
When the user asks for a page, component, landing page, dashboard, or any visual artifact:

1. Read the DESIGN.md file completely
2. Generate a single self-contained HTML file with:
   - All CSS in a `<style>` block using CSS custom properties from the design system
   - `:root` block with all color/typography tokens
   - Semantic HTML5 structure
   - Responsive layout
   - No external dependencies (fonts loaded via Google Fonts or system stacks)

### Markdown Output (default for documentation requests)
When the user asks for documentation, specs, or text content:

1. Read the DESIGN.md file completely
2. Generate Markdown that reflects the design system's:
   - Color references in code blocks
   - Typography specifications in tables
   - Component patterns as structured documentation

## Workflow

1. **Read** the DESIGN.md file at the path shown above
2. **Extract** the key design tokens:
   - Colors (primary, accent, neutral, semantic)
   - Typography (families, weights, scale)
   - Spacing and layout values
   - Component patterns
3. **Generate** output that uses these tokens consistently
4. **Validate** against the Do's and Don'ts section

## Token Mapping

Standard CSS variable names to use:
- `--bg` → background
- `--surface` → card/elevated surfaces
- `--fg` → primary text
- `--muted` → secondary text
- `--border` → borders and dividers
- `--accent` → primary interactive color
- `--success`, `--warn`, `--danger` → semantic colors
- `--font-display` → headings
- `--font-body` → body text
- `--font-mono` → code/technical

## Quality Checks

Before outputting, verify:
- [ ] All colors reference the design system's palette (no invented colors)
- [ ] Typography uses specified font families
- [ ] Spacing follows the design system's scale
- [ ] Component styles match the documented patterns
- [ ] No patterns from the "Don't" section appear

## Example Usage

User: "Create a landing page hero section"
→ Read DESIGN.md, generate HTML with hero using the system's color palette, typography, and spacing

User: "Document the color palette"
→ Read DESIGN.md, generate Markdown table with all colors, hex values, and usage notes

User: "Build a pricing card component"
→ Read DESIGN.md, generate HTML card component matching the system's card styling pattern
