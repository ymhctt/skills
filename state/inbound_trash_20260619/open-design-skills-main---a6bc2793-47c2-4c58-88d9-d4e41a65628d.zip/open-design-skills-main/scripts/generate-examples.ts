#!/usr/bin/env node --experimental-strip-types

/**
 * Generate example HTML and Markdown files for each design system skill.
 *
 * Usage:
 *   node --experimental-strip-types skills/generate-examples.ts [--force]
 */

import { readdir, readFile, writeFile, mkdir } from "fs/promises";
import { join } from "path";

const DESIGN_ROOT = join(import.meta.dirname, "..", "design-systems");
const SKILLS_DIR = join(import.meta.dirname, "..", "skills");
const FORCE = process.argv.includes("--force");

interface DesignTokens {
  name: string;
  category: string;
  description: string;
  colors: Record<string, string>;
  fonts: {
    display: string;
    body: string;
    mono: string;
  };
}

async function parseDesignMd(slug: string): Promise<DesignTokens | null> {
  const designPath = join(DESIGN_ROOT, slug, "DESIGN.md");
  try {
    const content = await readFile(designPath, "utf-8");
    const lines = content.split("\n");

    // Extract H1 title
    const h1Line = lines.find((l) => l.startsWith("# "));
    const rawTitle = h1Line?.replace(/^#\s+/, "") ?? slug;
    const name = rawTitle.replace(/^Design System Inspired by\s+/i, "").trim() || slug;

    // Extract category
    const categoryLine = lines.find((l) => l.startsWith("> Category:"));
    const category = categoryLine?.replace(/^>\s*Category:\s*/, "").trim() ?? "";

    // Extract description (line after category)
    const categoryIdx = lines.indexOf(categoryLine ?? "");
    const description = lines[categoryIdx + 1]?.replace(/^>\s*/, "").trim() ?? "";

    // Extract colors with priority-based mapping
    const colors: Record<string, string> = {};
    const allColors: Array<{ key: string; hex: string; priority: number }> = [];

    const colorSection = lines.findIndex((l) => l.includes("Color Palette"));
    if (colorSection > -1) {
      for (let i = colorSection; i < Math.min(colorSection + 100, lines.length); i++) {
        const line = lines[i];
        // Stop at next major section
        if (i > colorSection && line.startsWith("## ")) break;

        // Match various formats
        const match = line.match(/\*\*([^*]+)\*\*.*`#([0-9a-fA-F]{6})`/);
        if (match) {
          const rawKey = match[1].toLowerCase().trim();
          const hex = `#${match[2]}`;

          // Determine priority for token mapping
          let priority = 0;
          let tokenName = "";

          if (rawKey === "background" || rawKey === "bg" || rawKey === "page background" || rawKey === "canvas" || rawKey.includes("white") || rawKey.includes("pure white")) {
            tokenName = "background";
            priority = rawKey === "background" ? 10 : rawKey.includes("pure") ? 8 : 5;
          } else if (rawKey === "foreground" || rawKey === "fg" || rawKey === "text" || rawKey.includes("ink") || rawKey.includes("black")) {
            tokenName = "foreground";
            priority = rawKey === "foreground" ? 10 : rawKey.includes("ink") ? 8 : 5;
          } else if (rawKey.includes("accent") || rawKey.includes("primary") || rawKey.includes("brand") || rawKey.includes("purple") || rawKey.includes("blue")) {
            tokenName = "accent";
            priority = rawKey.includes("accent") ? 10 : rawKey.includes("primary") ? 8 : 5;
          } else if (rawKey.includes("surface") || rawKey.includes("card") || rawKey.includes("gray") || rawKey.includes("graphite")) {
            tokenName = "surface";
            priority = 8;
          } else if (rawKey.includes("muted") || rawKey.includes("secondary") || rawKey.includes("body")) {
            tokenName = "muted";
            priority = 8;
          } else if (rawKey.includes("border") || rawKey.includes("divider") || rawKey.includes("outline")) {
            tokenName = "border";
            priority = 8;
          } else if (rawKey.includes("success")) {
            tokenName = "success";
            priority = 5;
          } else if (rawKey.includes("warn") || rawKey.includes("warning")) {
            tokenName = "warn";
            priority = 5;
          } else if (rawKey.includes("danger") || rawKey.includes("error")) {
            tokenName = "danger";
            priority = 5;
          }

          if (tokenName) {
            allColors.push({ key: tokenName, hex, priority });
          }
        }
      }
    }

    // Apply colors with highest priority wins
    for (const { key, hex, priority } of allColors) {
      if (!colors[key] || priority > (colors[key + "_priority"] || 0)) {
        colors[key] = hex;
        colors[key + "_priority"] = String(priority);
      }
    }

    // Clean up priority keys
    Object.keys(colors).forEach((k) => {
      if (k.endsWith("_priority")) delete colors[k];
    });

    // Extract fonts
    const fonts = { display: "system-ui, sans-serif", body: "system-ui, sans-serif", mono: "monospace" };
    const typoSection = lines.findIndex((l) => l.includes("Typography"));
    if (typoSection > -1) {
      for (let i = typoSection; i < Math.min(typoSection + 40, lines.length); i++) {
        const line = lines[i];
        // Stop at next major section
        if (i > typoSection && line.startsWith("## ")) break;

        if (line.includes("Display") || line.includes("heading") || line.includes("Headline") || line.includes("Headings")) {
          const fontMatch = line.match(/`([^`]+)`/);
          if (fontMatch) fonts.display = fontMatch[1];
        }
        if ((line.includes("Body") || line.includes("body text")) && !line.includes("Mono")) {
          const fontMatch = line.match(/`([^`]+)`/);
          if (fontMatch) fonts.body = fontMatch[1];
        }
        if (line.includes("Mono") || line.includes("mono") || line.includes("Code") || line.includes("monospace")) {
          const fontMatch = line.match(/`([^`]+)`/);
          if (fontMatch) fonts.mono = fontMatch[1];
        }
      }
    }

    return { name, category, description, colors, fonts };
  } catch {
    return null;
  }
}

function generateHtml(tokens: DesignTokens, slug: string): string {
  const accent = tokens.colors["accent"] || "#2F6FEB";
  const bg = tokens.colors["background"] || "#FAFAFA";
  const fg = tokens.colors["foreground"] || "#111111";
  const surface = tokens.colors["surface"] || "#FFFFFF";
  const muted = tokens.colors["muted"] || "#6B6B6B";
  const border = tokens.colors["border"] || "#E5E5E5";

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${tokens.name} — Design System Example</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: ${bg};
      --surface: ${surface};
      --fg: ${fg};
      --muted: ${muted};
      --border: ${border};
      --accent: ${accent};
      --font-display: ${tokens.fonts.display};
      --font-body: ${tokens.fonts.body};
      --font-mono: ${tokens.fonts.mono};
    }

    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
      font-family: var(--font-body);
      background: var(--bg);
      color: var(--fg);
      line-height: 1.6;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      padding: 0 24px;
    }

    .hero {
      padding: 80px 0;
      text-align: center;
    }

    .hero h1 {
      font-family: var(--font-display);
      font-size: 3rem;
      font-weight: 700;
      margin-bottom: 16px;
      letter-spacing: -0.02em;
    }

    .hero p {
      font-size: 1.25rem;
      color: var(--muted);
      max-width: 600px;
      margin: 0 auto 32px;
    }

    .hero .badge {
      display: inline-block;
      background: var(--accent);
      color: white;
      padding: 4px 12px;
      border-radius: 20px;
      font-size: 0.875rem;
      font-weight: 500;
      margin-bottom: 24px;
    }

    .btn {
      display: inline-block;
      padding: 12px 24px;
      border-radius: 8px;
      font-weight: 600;
      text-decoration: none;
      transition: all 0.2s;
      cursor: pointer;
    }

    .btn-primary {
      background: var(--accent);
      color: white;
    }

    .btn-primary:hover {
      opacity: 0.9;
      transform: translateY(-1px);
    }

    .btn-secondary {
      background: transparent;
      color: var(--fg);
      border: 1px solid var(--border);
    }

    .btn-secondary:hover {
      border-color: var(--accent);
      color: var(--accent);
    }

    .btn-group {
      display: flex;
      gap: 12px;
      justify-content: center;
    }

    .cards {
      padding: 80px 0;
    }

    .cards h2 {
      font-family: var(--font-display);
      font-size: 2rem;
      text-align: center;
      margin-bottom: 48px;
    }

    .card-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 24px;
    }

    .card {
      background: var(--surface);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 24px;
      transition: all 0.2s;
    }

    .card:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
    }

    .card h3 {
      font-size: 1.25rem;
      margin-bottom: 8px;
    }

    .card p {
      color: var(--muted);
      font-size: 0.9375rem;
    }

    .card .icon {
      width: 48px;
      height: 48px;
      background: var(--accent);
      border-radius: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 16px;
      font-size: 1.5rem;
    }

    .stats {
      padding: 80px 0;
      background: var(--surface);
    }

    .stat-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 32px;
      text-align: center;
    }

    .stat-number {
      font-family: var(--font-display);
      font-size: 2.5rem;
      font-weight: 700;
      color: var(--accent);
    }

    .stat-label {
      color: var(--muted);
      font-size: 0.875rem;
      margin-top: 4px;
    }

    .footer {
      padding: 48px 0;
      text-align: center;
      border-top: 1px solid var(--border);
    }

    .footer p {
      color: var(--muted);
      font-size: 0.875rem;
    }

    @media (max-width: 768px) {
      .hero h1 { font-size: 2rem; }
      .stat-grid { grid-template-columns: repeat(2, 1fr); }
    }
  </style>
</head>
<body>
  <section class="hero">
    <div class="container">
      <span class="badge">${tokens.category}</span>
      <h1>${tokens.name}</h1>
      <p>${tokens.description}</p>
      <div class="btn-group">
        <a href="#" class="btn btn-primary">Get Started</a>
        <a href="#" class="btn btn-secondary">Learn More</a>
      </div>
    </div>
  </section>

  <section class="cards">
    <div class="container">
      <h2>Features</h2>
      <div class="card-grid">
        <div class="card">
          <div class="icon">🎨</div>
          <h3>Design Tokens</h3>
          <p>Consistent colors, typography, and spacing across all components.</p>
        </div>
        <div class="card">
          <div class="icon">📐</div>
          <h3>Layout System</h3>
          <p>Responsive grid with flexible columns and gutters.</p>
        </div>
        <div class="card">
          <div class="icon">✨</div>
          <h3>Components</h3>
          <p>Pre-built UI elements that follow the design language.</p>
        </div>
      </div>
    </div>
  </section>

  <section class="stats">
    <div class="container">
      <div class="stat-grid">
        <div>
          <div class="stat-number">150+</div>
          <div class="stat-label">Design Systems</div>
        </div>
        <div>
          <div class="stat-number">9</div>
          <div class="stat-label">Categories</div>
        </div>
        <div>
          <div class="stat-number">100%</div>
          <div class="stat-label">Open Source</div>
        </div>
        <div>
          <div class="stat-number">∞</div>
          <div class="stat-label">Possibilities</div>
        </div>
      </div>
    </div>
  </section>

  <footer class="footer">
    <div class="container">
      <p>Generated from ${slug}/DESIGN.md — ${tokens.name} Design System</p>
    </div>
  </footer>
</body>
</html>`;
}

function generateMarkdown(tokens: DesignTokens, slug: string): string {
  const accent = tokens.colors["accent"] || "#2F6FEB";
  const bg = tokens.colors["background"] || "#FAFAFA";
  const fg = tokens.colors["foreground"] || "#111111";
  const surface = tokens.colors["surface"] || "#FFFFFF";
  const muted = tokens.colors["muted"] || "#6B6B6B";
  const border = tokens.colors["border"] || "#E5E5E5";

  return `# ${tokens.name} Design System

> ${tokens.description}

## Color Palette

| Token | Value | Preview |
|-------|-------|---------|
| \`--bg\` | \`${bg}\` | ![${bg}](https://via.placeholder.com/20/${bg.replace('#','')}/${bg.replace('#','')}) |
| \`--surface\` | \`${surface}\` | ![${surface}](https://via.placeholder.com/20/${surface.replace('#','')}/${surface.replace('#','')}) |
| \`--fg\` | \`${fg}\` | ![${fg}](https://via.placeholder.com/20/${fg.replace('#','')}/${fg.replace('#','')}) |
| \`--muted\` | \`${muted}\` | ![${muted}](https://via.placeholder.com/20/${muted.replace('#','')}/${muted.replace('#','')}) |
| \`--border\` | \`${border}\` | ![${border}](https://via.placeholder.com/20/${border.replace('#','')}/${border.replace('#','')}) |
| \`--accent\` | \`${accent}\` | ![${accent}](https://via.placeholder.com/20/${accent.replace('#','')}/${accent.replace('#','')}) |

## Typography

| Role | Font Family |
|------|-------------|
| Display / Headings | \`${tokens.fonts.display}\` |
| Body | \`${tokens.fonts.body}\` |
| Monospace | \`${tokens.fonts.mono}\` |

## CSS Custom Properties

\`\`\`css
:root {
  --bg: ${bg};
  --surface: ${surface};
  --fg: ${fg};
  --muted: ${muted};
  --border: ${border};
  --accent: ${accent};
  --font-display: ${tokens.fonts.display};
  --font-body: ${tokens.fonts.body};
  --font-mono: ${tokens.fonts.mono};
}
\`\`\`

## Component Examples

### Button

\`\`\`html
<button class="btn btn-primary">Get Started</button>
<button class="btn btn-secondary">Learn More</button>
\`\`\`

\`\`\`css
.btn {
  padding: 12px 24px;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
}

.btn-primary {
  background: var(--accent);
  color: white;
  border: none;
}

.btn-secondary {
  background: transparent;
  color: var(--fg);
  border: 1px solid var(--border);
}
\`\`\`

### Card

\`\`\`html
<div class="card">
  <h3>Card Title</h3>
  <p>Card content goes here.</p>
</div>
\`\`\`

\`\`\`css
.card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 24px;
}
\`\`\`

## Layout

- **Max width:** 1200px
- **Grid:** 12 columns
- **Gutters:** 24px
- **Section spacing:** 80px (desktop), 48px (tablet), 32px (mobile)

## Source

Generated from [\`${slug}/DESIGN.md\`](../${slug}/DESIGN.md)
`;
}

async function main() {
  const entries = await readdir(DESIGN_ROOT, { withFileTypes: true });
  const designDirs = entries.filter(
    (e) => e.isDirectory() && !e.name.startsWith(".") && e.name !== "skills"
  );

  console.log(`Found ${designDirs.length} design systems`);

  let created = 0;
  let skipped = 0;

  for (const dir of designDirs) {
    const tokens = await parseDesignMd(dir.name);
    if (!tokens) continue;

    const skillDir = join(SKILLS_DIR, dir.name);
    await mkdir(skillDir, { recursive: true });

    const htmlPath = join(skillDir, "example.html");
    const mdPath = join(skillDir, "example.md");

    try {
      if (!FORCE) {
        await readFile(htmlPath, "utf-8");
        skipped++;
        continue;
      }
    } catch {
      // Doesn't exist, create
    }

    const html = generateHtml(tokens, dir.name);
    const md = generateMarkdown(tokens, dir.name);

    await writeFile(htmlPath, html, "utf-8");
    await writeFile(mdPath, md, "utf-8");
    created++;
  }

  console.log(`Created examples: ${created}, Skipped: ${skipped}`);
}

main().catch(console.error);
