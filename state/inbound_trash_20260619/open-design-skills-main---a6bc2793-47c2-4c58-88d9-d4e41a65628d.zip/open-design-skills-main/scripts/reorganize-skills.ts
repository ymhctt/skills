#!/usr/bin/env node --experimental-strip-types

/**
 * Reorganize skill directories following skill-creator conventions.
 *
 * Structure per skill:
 *   design-<slug>/
 *   ├── SKILL.md           ← Main skill file (embedded DESIGN.md)
 *   ├── examples/          ← Example outputs
 *   │   ├── example.html   ← HTML example
 *   │   └── example.md     ← Markdown example
 *   └── references/        ← Original source files
 *       ├── DESIGN.md      ← Original design spec
 *       └── tokens.css     ← CSS tokens (if available)
 *
 * Usage:
 *   node --experimental-strip-types skills/reorganize-skills.ts
 */

import { readdir, readFile, writeFile, mkdir, rename, stat } from "fs/promises";
import { join } from "path";

const DESIGN_ROOT = join(import.meta.dirname, "..", "design-systems");
const SKILLS_DIR = join(import.meta.dirname, "..", "skills");

async function fileExists(path: string): Promise<boolean> {
  try {
    await stat(path);
    return true;
  } catch {
    return false;
  }
}

async function main() {
  const entries = await readdir(DESIGN_ROOT, { withFileTypes: true });
  const designDirs = entries.filter(
    (e) => e.isDirectory() && !e.name.startsWith(".") && e.name !== "skills"
  );

  console.log(`Processing ${designDirs.length} design systems`);

  let processed = 0;
  let skipped = 0;

  for (const dir of designDirs) {
    const skillDir = join(SKILLS_DIR, dir.name);
    const examplesDir = join(skillDir, "examples");
    const refsDir = join(skillDir, "references");

    // Check if already reorganized
    if (await fileExists(join(examplesDir, "example.html"))) {
      skipped++;
      continue;
    }

    // Create directories
    await mkdir(examplesDir, { recursive: true });
    await mkdir(refsDir, { recursive: true });

    // Move example files to examples/
    const htmlSrc = join(skillDir, "example.html");
    const mdSrc = join(skillDir, "example.md");

    if (await fileExists(htmlSrc)) {
      await rename(htmlSrc, join(examplesDir, "example.html"));
    }
    if (await fileExists(mdSrc)) {
      await rename(mdSrc, join(examplesDir, "example.md"));
    }

    // Copy original DESIGN.md to references/
    const designSrc = join(DESIGN_ROOT, dir.name, "DESIGN.md");
    if (await fileExists(designSrc) && !await fileExists(join(refsDir, "DESIGN.md"))) {
      const content = await readFile(designSrc, "utf-8");
      await writeFile(join(refsDir, "DESIGN.md"), content, "utf-8");
    }

    // Copy tokens.css if exists
    const tokensSrc = join(DESIGN_ROOT, dir.name, "tokens.css");
    if (await fileExists(tokensSrc) && !await fileExists(join(refsDir, "tokens.css"))) {
      const content = await readFile(tokensSrc, "utf-8");
      await writeFile(join(refsDir, "tokens.css"), content, "utf-8");
    }

    processed++;
  }

  console.log(`\nResults:`);
  console.log(`  Processed: ${processed}`);
  console.log(`  Skipped (already done): ${skipped}`);
  console.log(`\nEach skill now has:`);
  console.log(`  - SKILL.md (standalone with embedded design spec)`);
  console.log(`  - examples/example.html (HTML example)`);
  console.log(`  - examples/example.md (Markdown example)`);
  console.log(`  - references/DESIGN.md (original source)`);
  console.log(`  - references/tokens.css (if available)`);
}

main().catch(console.error);
