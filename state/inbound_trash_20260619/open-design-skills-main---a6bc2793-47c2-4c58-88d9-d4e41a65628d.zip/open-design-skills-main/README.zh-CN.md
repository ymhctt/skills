# 设计系统

[English](README.md) | [中文](README.zh-CN.md)

所有设计系统文件都来源于 [open-design](https://github.com/nexu-io/open-design) 项目的 [`design-systems`](https://github.com/nexu-io/open-design/tree/main/design-systems) 目录。

每个子文件夹都是一个可移植的设计系统，采用 `DESIGN.md` 格式。

## 设计系统 Skills

150+ 个独立的 skill 文件夹，用于根据设计系统规范生成 HTML/Markdown。

每个 skill **完全独立** — 可将文件夹拷贝到任何地方独立使用。

### Skill 结构

```
skills/<slug>/
├── SKILL.md           ← 主 skill 文件（已嵌入 DESIGN.md）
├── examples/          ← 示例输出
│   ├── example.html   ← HTML 示例
│   └── example.md     ← Markdown 示例
└── references/        ← 原始源文件
    ├── DESIGN.md      ← 设计规范
    └── tokens.css     ← CSS tokens（如有）
```

### 使用方式

**创建落地页：**
```
/design-stripe 创建一个带有 CTA 按钮的 hero 区域
```

**生成组件：**
```
/design-apple 构建一个定价卡片组件
```

**文档化颜色方案：**
```
/design-figma 用 markdown 表格列出所有颜色
```

### 重新生成 Skills

```bash
# 重新生成 SKILL.md 文件（使用 --force 覆盖）
node --experimental-strip-types scripts/generate-skills.ts --force

# 重新生成示例文件
node --experimental-strip-types scripts/generate-examples.ts --force

# 重组 references 目录
node --experimental-strip-types scripts/reorganize-skills.ts
```