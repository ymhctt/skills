# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This directory (`open-design-skills/`) is part of the [open-design](../open-design/) monorepo. It contains **150+ design systems** — each a self-contained folder with design tokens, component specs, and usage docs. The parent project uses `pnpm` workspaces.

## Design System Skills

Each design system has a self-contained skill folder in `skills/<slug>/`:

```
skills/<slug>/
├── SKILL.md           ← Main skill file (DESIGN.md embedded)
├── examples/          ← Example outputs
│   ├── example.html   ← HTML example
│   └── example.md     ← Markdown example
└── references/        ← Original source files
    ├── DESIGN.md      ← Design specification
    └── tokens.css     ← CSS tokens (if available)
```

Each skill is fully standalone — copy the folder anywhere to use it independently.

## Design System Structure

Each subfolder follows this shape:

```
<slug>/
├── DESIGN.md                    ← canonical design prose (required)
├── tokens.css                   ← CSS custom properties (optional)
├── components.html              ← standalone component fixture (optional)
├── manifest.json                ← machine-readable metadata (optional)
├── USAGE.md                     ← agent-facing package guide (optional)
├── components.manifest.json     ← component cache (optional)
└── preview/                     ← static preview pages (optional)
```

### DESIGN.md Format

- First H1 is the picker title
- Line after H1: `> Category: <Group>` (used for dropdown grouping)
- Standard 9 sections: Visual Theme, Color Palette, Typography, Component Stylings, Layout Principles, Depth & Elevation, Do's and Don'ts, Micro-interactions, Accessibility

### tokens.css Contract

Standard token names enforced by lint:
- Colors: `--bg`, `--surface`, `--fg`, `--muted`, `--border`, `--accent`, `--success`, `--warn`, `--danger`
- Typography: `--font-display`, `--font-body`, `--font-mono`
- Raw hex values >12 chars outside `:root` block triggers P1 lint error

### manifest.json Schema

```json
{
  "schemaVersion": "od-design-system-project/v1",
  "id": "<slug>",
  "name": "<Display Name>",
  "category": "<Group>",
  "description": "<one-line>",
  "source": { "type": "bundled", "origin": "hand-authored" },
  "files": { "design": "DESIGN.md", "tokens": "tokens.css" }
}
```

Validated by `pnpm guard` in parent repo.

## Common Commands

Run from `../open-design/` (parent directory):

```bash
pnpm guard          # validate manifests + run style/product-neutrality tests
pnpm typecheck      # TypeScript type checking across workspace
```

## Key Conventions

- Folder names use ASCII slugs; dotted brands normalized (`linear.app` → `linear-app`)
- Legacy folders with only `DESIGN.md` are still supported
- New systems should include `manifest.json` for picker/daemon discovery
- Attribution required for imported systems (see README.md)
- **Multilingual README sync**: When updating `README.md`, also update `README.zh-CN.md` in the same change. Both versions must reflect the same content.

---

# Behavioral Guidelines

Guidelines to reduce common LLM coding mistakes. Merge with project-specific instructions as needed.

**Tradeoff:** These guidelines bias toward caution over speed. For trivial tasks, use judgment.

## 1. Think Before Coding

**Don't assume. Don't hide confusion. Surface tradeoffs.**

Before implementing:
- State your assumptions explicitly. If uncertain, ask.
- If multiple interpretations exist, present them - don't pick silently.
- If a simpler approach exists, say so. Push back when warranted.
- If something is unclear, stop. Name what's confusing. Ask.

## 2. Simplicity First

**Minimum code that solves the problem. Nothing speculative.**

- No features beyond what was asked.
- No abstractions for single-use code.
- No "flexibility" or "configurability" that wasn't requested.
- No error handling for impossible scenarios.
- If you write 200 lines and it could be 50, rewrite it.

Ask yourself: "Would a senior engineer say this is overcomplicated?" If yes, simplify.

## 3. Surgical Changes

**Touch only what you must. Clean up only your own mess.**

When editing existing code:
- Don't "improve" adjacent code, comments, or formatting.
- Don't refactor things that aren't broken.
- Match existing style, even if you'd do it differently.
- If you notice unrelated dead code, mention it - don't delete it.

When your changes create orphans:
- Remove imports/variables/functions that YOUR changes made unused.
- Don't remove pre-existing dead code unless asked.

The test: Every changed line should trace directly to the user's request.

## 4. Goal-Driven Execution

**Define success criteria. Loop until verified.**

Transform tasks into verifiable goals:
- "Add validation" → "Write tests for invalid inputs, then make them pass"
- "Fix the bug" → "Write a test that reproduces it, then make it pass"
- "Refactor X" → "Ensure tests pass before and after"

For multi-step tasks, state a brief plan:
```
1. [Step] → verify: [check]
2. [Step] → verify: [check]
3. [Step] → verify: [check]
```

Strong success criteria let you loop independently. Weak criteria ("make it work") require constant clarification.



## Rule 5 — Use the model only for judgment calls
Use me for: classification, drafting, summarization, extraction.
Do NOT use me for: routing, retries, deterministic transforms.
If code can answer, code answers.

## Rule 6 — Token budgets are not advisory
Per-task: 4,000 tokens. Per-session: 30,000 tokens.
If approaching budget, summarize and start fresh.
Surface the breach. Do not silently overrun.

## Rule 7 — Surface conflicts, don't average them
If two patterns contradict, pick one (more recent / more tested).
Explain why. Flag the other for cleanup.
Don't blend conflicting patterns.

## Rule 8 — Read before you write
Before adding code, read exports, immediate callers, shared utilities.
"Looks orthogonal" is dangerous. If unsure why code is structured a way, ask.

## Rule 9 — Tests verify intent, not just behavior
Tests must encode WHY behavior matters, not just WHAT it does.
A test that can't fail when business logic changes is wrong.

## Rule 10 — Checkpoint after every significant step
Summarize what was done, what's verified, what's left.
Don't continue from a state you can't describe back.
If you lose track, stop and restate.

## Rule 11 — Match the codebase's conventions, even if you disagree
Conformance > taste inside the codebase.
If you genuinely think a convention is harmful, surface it. Don't fork silently.

## Rule 12 — Fail loud
"Completed" is wrong if anything was skipped silently.
"Tests pass" is wrong if any were skipped.
Default to surfacing uncertainty, not hiding it.



## Rule 13 — Keep multilingual READMEs in sync

When updating README.md, also update README.zh-CN.md (and any other language versions) in the same change.
All language versions must reflect the same content, structure, and level of detail.

## Rule 14 — Use git-commit-message for commits

When creating a git commit in this repository, use the `git-commit-message` skill first to draft the commit message, then commit with that message.

---

**These guidelines are working if:** fewer unnecessary changes in diffs, fewer rewrites due to overcomplication, and clarifying questions come before implementation rather than after mistakes.



