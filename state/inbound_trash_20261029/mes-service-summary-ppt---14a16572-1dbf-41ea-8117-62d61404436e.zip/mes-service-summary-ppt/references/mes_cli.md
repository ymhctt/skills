# MES CLI 命令与坑（服务总结 PPT 取数）

## 鉴权与连通性

- MES CLI 经公司 VPN 调用。未连 VPN 时 `auth status` 报 `server unreachable`；连上 VPN 后自愈，**不要手动加证书或 curl 兜底**。
- 证书偶发 `-26276`（OSStatus）：VPN 断开/会话上下文拿不到钥匙串信任锚所致，重连 VPN 即可。

## 合同检索的坑（关键）

- `mes contract list --search 合同号` **只覆盖"我的合同"且不含到期归档项**，对 00032215 / 00032375 等均返回 0。
- **不要依赖合同号检索**。让用户直接给 **accId（子项 ID，13 位数字）**，用 `statistics list --acc-id` 拉全量报工。
- 已知 accId↔项目示例：
  - `2025060911701` = 上期所 2025 年驻场（客户 上期所 companyId 200）
  - `2025082812000` = 新疆银行 2025 驻场（companyId 412，PM 苏明月）
  - `2026012812602` = 新疆农信 2026 驻场（companyId 423，PM 苏明月）
  - `2026012812603` = 新疆农信 zCloud
  - `2025092612083`~`2025092612088` = 青岛银行 2025 系统运维外包（companyId 650，负责人 王乐飞，6 子项）

## 反查合同元信息与子项计划工时（推荐）

用**合同号**直接反查，一次拿全 companyId / 客户名 / 负责人 / 周期 / 子项：

```bash
mes -o json contract list-items --contract-num 00032416 --include-expired --page-size 50
```

- 数据在 `operateCallBackObj.list`；关键字段：`companyId`、`companyName`、`ownerName`（项目经理/负责人）、`itemId`（子项 accId）、`itemName`、`itemType`、`planHour`、`actualHours`、`startTime`、`endTime`。
- **必须加 `--include-expired`**（或 `--unlimited-end-time`），否则已结束合同的子项会被过滤掉。
- `actualHours` 与 `statistics list` 聚合结果可能略有差异（口径/审批状态不同）——**以 `statistics list` 全量明细为准**，`planHour` 用于子项页的"计划工时"。

## 拉取报工（正确姿势）

```bash
mes -o json statistics list --acc-id ACCID --from YYYY-MM-DD --to YYYY-MM-DD --page-size 100 --page N
```

- 数据在 `list` 数组；分页信息在 `pages` / `total`。循环翻页直到取完所有页。
- **page-size 必须用 100**。500 触发 HTTP/2 流错误（`stream error`）。
- 每条记录关键字段：`executorName`（执行人）、`taskTime`（工时，单位小时）、`start`（开始时间，ISO）、`remark`（报工说明）、`title`（标题）、`reviewStatus`（0 待审批 / 1 已审批）。
- 报工记录 `teamId` 多为 null，但 `teamName` 有值，可按 teamName 归类。
- **重名检测**：同姓名多 `executorId` 需谨慎；实测项目暂无重名冲突。"无员工档案"的执行人 key 形如 `候静远(无员工档案)`，聚合时须用完整 key。

## 千万不能用的口径

- `mes statistics summary` 的 `totalTaskTime` **只计已审批（reviewStatus=1）工时**；待审批不计入 → 会虚假判为"未报工"。
- 准确统计必须用 `statistics list`（分页拉全量，含所有 reviewStatus），按 `executorName` 聚合每日/总工时。

## 团队与部门 ID（2026-10 现状，备查）

- MES 组织已从"东西大区 1/2/4/5 部"重组为 **服务 1 部~服务 7 部**（另有电信行业服务部、市场部、创新服务中心等）。
- team-id 映射：服务1部=25、服务2部=11、服务3部=3、服务4部=23、服务5部=19、服务6部=22、服务7部=9312。
- `mes dashboard team` 可列全部团队 teamId/teamName。

## 排除名单（mes_no_word 默认过滤，不在消息显示）

许文榕、杨明翰、周瑞斌、李华、贾泽伟。
