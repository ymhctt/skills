# meta.json 字段说明

`meta.json` 由用户/代理按合同真实情况填写，驱动 PPT 的叙述型页面。渲染器（`build_pptx.js`）会读取它并做字段兜底。所有字符串字段支持中文；数值字段为字符串或数字均可。

## 必填（决定能否出图与封面/概况）

| 字段 | 类型 | 说明 | 示例 |
|---|---|---|---|
| `title` | string | PPT 主标题（同时用于文件名） | `"新疆银行 2025 年数据库驻场服务总结"` |
| `contractNo` | string | 合同号 | `"00032375"` |
| `accIds` | string[] | 子项 accId 列表（与 data.json 对应） | `["2025082812000","2025112012275","2025112012274"]` |
| `accIdEmpty` | string[] | 可选。报工为 0 的子项，封面/概况透明标注 | `["2025112012273"]` |
| `companyName` | string | 客户公司全称 | `"新疆银行股份有限公司"` |
| `companyId` | number/string | 客户公司 ID | `412` |
| `pm` | string | 项目经理 | `"苏明月"` |
| `startDate` | string | 服务开始（YYYY-MM） | `"2025-08"` |
| `endDate` | string | 服务截止（YYYY-MM，常写"至今"或数据截至月） | `"2026-08"` |
| `serviceScope` | string | 服务范围概述（优先来自 服务内容.docx） | `"数据库驻场运维保障，覆盖 Oracle、达梦、GaussDB、OceanBase…"` |
| `dbStack` | string[] | 技术栈/纳管范围标签（技术栈页用） | `["Oracle 28 套","达梦(DM) 33–35 套","GaussDB 高斯","OceanBase(OB)","GBase8s","MySQL","zCloud 云管平台"]` |

## 叙述型（强烈建议填，缺省自动兜底但质量低）

| 字段 | 类型 | 说明 |
|---|---|---|
| `subtitle` | string | 封面副标题，缺省用 `"恩墨 · 驻场运维交付报告"` |
| `techGroups` | object[] | 技术栈页三列卡：`{icon,title,color,items[]}`；缺省由 `dbStack` 自动切三列 |
| `teamRoles` | object[] | 人员页前 3 张角色卡：`{name,role,desc,col}`（col 为 6 位 hex，如 `"0F2C4C"`）；缺省按工时前三自动定位 |
| `subItems` | object[] | **合同子项投入页（可选，出现即插入一页）**：`{id,name,type,plan,actual}`；plan/actual 为小时数。数据来自 `mes contract list-items --contract-num` 的 `planHour` 与 `statistics list` 聚合 |
| `domesticDb` | object[] | 国产库专项页卡片：`{name, count, desc}`；缺省由关键词命中自动生成 |
| `keyCases1` | object[] | 故障/保障关键案例：`{icon, title, problem, action}`（4 条） |
| `keyCases2` | object[] | 性能/迁移关键案例：`{name, before, act, after}`（4 条） |
| `valueItems` | object[] | 价值体现 6 卡：`{icon, title, desc}`；缺省由主题自动生成 |
| `deliverables` | object[] | 交付成果物 6 卡：`{icon, title, desc}` |
| `sla` | object | `{response:[[k,v]...], recovery:[[lv,desc,sla]...]}`；缺省用标准模板 |
| `nextSteps` | string[] | 展望页"下一步行动"（3 条） |

> 说明：页码由渲染器内部的 `PAGE` 计数器统一编号（`footer(s, ++PAGE)`），插入/删除可选页（如 `subItems` 页）后页码会自动连续，无需手工改页脚。

## 可选覆盖

| 字段 | 类型 | 说明 |
|---|---|---|
| `metrics` | object | 封面四宫格覆盖：`{n, hours, personDays, people}`；缺省由 data.json 自动算 |
| `summaryLine` | string | 核心结论页主句；缺省自动生成 |
| `footText` | string | 页脚左文；缺省自动用"客户名 年份 驻场服务总结 · 恩墨交付" |

## 完整示例

见 `assets/sample_meta.json`（以 00032375 / 新疆银行为范本，可直接 `cp` 后改）。
