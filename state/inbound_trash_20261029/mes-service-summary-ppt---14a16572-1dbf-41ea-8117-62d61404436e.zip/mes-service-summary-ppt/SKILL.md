---
name: mes-service-summary-ppt
description: "Generate a polished, chart-rich MES service-summary presentation (.pptx) for a delivered contract. This skill should be used when the user asks to turn MES work-report (报工) data for one or more contract sub-items (accId) into a beautiful 驻场服务总结 / 服务总结 PPT, optionally referencing a 服务内容.docx. Covers pulling full work-report data via the MES CLI, single-label theme classification, pptxgenjs rendering with native editable charts, a python-pptx geometry audit (no LibreOffice needed), and a speech script."
---

# MES 服务总结 PPT 生成技能

把"一份合同 + 其下若干报工子项（accId）"的全量 MES 报工数据，渲染成一份**美观、有图表、有结论、可编辑**的驻场/服务总结 PPT（默认 14 页，含 4 张原生图表）。

遵循「台风 · 汇报演讲专家」方法论：先定三要素（听众=客户/内部评审、目的=交付价值证明、时长≈10–15 分钟），再搭四步结构（痛点→观点→论据→行动）；每页一观点、结论式标题；图表原生可编辑，不用截图。

## 何时使用

- 用户说"给合同 XXXXX 生成服务总结 PPT / 报工 PPT / 驻场总结 PPT"
- 用户给定合同号 + 一个或多个 accId（子项 ID），要求基于全量报工出图
- 用户附加一份 `服务内容.docx` 作为合同服务范围参考

## 工作流（严格按序）

### 1. 收集输入

向用户确认（若未提供）：
- **合同号**（如 `00032375`）与**子项 accId 列表**（13 位数字，如 `2025082812000`）
- **服务周期**起止（用于拉数；默认从 `2010-01-01` 到今天）
- 可选：**服务内容.docx 路径**（用 `scripts/read_docx.py` 抽文本，填进 `meta.serviceScope`）
- 可选：**项目经理、客户公司名/ID**（用于封面与概况页；可由 `mes contract list-items` 推断）

> 重要坑：MES `contract list --search 合同号` 常返回 0（只覆盖"我的合同"且不含到期归档项）。**不要依赖合同号检索**——直接要 accId，用 `mes statistics list --acc-id` 拉。详见 `references/mes_cli.md`。

> 反查合同信息（强烈推荐）：`mes -o json contract list-items --contract-num 合同号 --include-expired --page-size 50` 可一次拿到 **companyId / companyName / ownerName（项目经理）/ startTime / endTime**，以及每个子项的 **itemName / itemType / planHour / actualHours**。用它填 `meta.companyId / pm / startDate / endDate / subItems`，比手工猜准得多。

### 2. 拉取并聚合报工数据

```bash
python3 scripts/mes_pull.py \
  --acc-ids 2025082812000,2025112012275,2025112012274 \
  --from 2025-01-01 --to 2026-12-31 \
  --out ./data.json
```

脚本调用 `mes statistics list --acc-id ACCID --from FROM --to TO --page-size 100 --page N`（**page-size 必须用 100**，500 触发 HTTP/2 流错误），分页拉全量，**含所有 reviewStatus**（不要用 `statistics summary`，它只计已审批工时，会虚假判为"未报工"）。输出 `data.json`，每条记录保留 `executorName / taskTime / start / remark / title`。

### 3. 编写 meta.json（决定叙述质量）

复制 `assets/sample_meta.json` 为 `./meta.json`，按本合同的真实情况填写。字段说明见 `references/meta_schema.md`。**至少填**：`title / contractNo / accIds / companyName / pm / startDate / endDate / serviceScope / dbStack`。叙述型字段（`domesticDb / keyCases1 / keyCases2 / valueItems / deliverables / sla / nextSteps`）若不填，渲染器会用数据自动推导兜底，**但质量远低于手工填写**——优先从 docx 与报工 remark 中提炼真实案例。

### 4. 渲染 PPTX

```bash
cd scripts && npm install   # 仅首次，安装 pptxgenjs
cd ..
node scripts/build_pptx.js --meta ./meta.json --data ./data.json --out ./服务总结.pptx
```

渲染器内部完成：月度/季度工时、人员投入、单标签主题分类（**加权打分**，见 `references/theme_classification.md`）、国产库关键词命中统计，再生成 14 页。封面/概况/月度/人员/主题/技术栈页完全由数据驱动；国产库专项、关键案例、价值、成果物、SLA、展望页由 `meta` 驱动（缺省自动兜底）。

- 若填了 `meta.subItems`（来自 `contract list-items` 的子项与计划工时），会在"项目概况"后**自动插入一页"合同子项投入"**，总页数变 15；页码由内部计数器统一处理，无需手改页脚。
- 子项较多（≥4）或合同明确按子项交付时，建议填 `subItems` 单列一页。

### 5. 几何审计（替代 LibreOffice 视觉巡检）

环境通常无 LibreOffice/poppler，无法转图。改用 `python-pptx` 读回几何：

```bash
python3 scripts/audit_pptx.py ./服务总结.pptx
```

检查每页 shape 是否出界（x/w 超出 13.33×7.5）、文本是否溢出底边。封面/尾页的装饰圆（故意出血）属真阴性，可忽略。修复报告中的 OOB/碰撞后再交付。

### 6. 演讲稿与上台提醒

依据 `meta` 与数据，产出一份 `演讲稿与上台提醒.md`：开场 3 秒抓人、每页一句口播要点、结尾行动号召；附控语速/留停顿/眼神/手势的上台提醒清单。结构参考本技能自带方法论即可，不必另起技能。

## 设计系统（已固化在 build_pptx.js，无需改）

- 宽屏 `LAYOUT_WIDE`（13.33×7.5）；深海军蓝 `0F2C4C` + 青 `0E9594` + 金 `E0A526` 三明治配色；中文字体 `Microsoft YaHei`，数字 `Georgia`。
- 每页：左上青色方块 kicker + 结论式大标题；底部 footer（项目名 + 页码）；卡片统一 `card()`（白底 + 左侧青条 + 软阴影）。
- 4 张原生图表：月度柱图、人员环形图（含合计工时中心标签）、主题横向柱图（带值标签）、季度趋势（如需要）。**全部 pptxgenjs 原生，可双击编辑**。

## 复用要点 / 反模式

- ✅ 全量 `statistics list` 拉数 → 本地聚合 → 渲染，三合同同构验证过。
- ✅ 子项报工为 0 时，在封面/概况透明标注"暂无报工"，**绝不虚构**。
- ❌ 不要用 `statistics summary` 的 totalTaskTime（只计已审批）。
- ❌ 不要对某主题用多标签（小时数会超过总计）；用单标签优先级分类使维度图求和正确。
- ❌ 柱状图 `valAxisMaxVal` 必须留 20% 余量，否则裁掉峰值（如 336h 被 220 上限吃掉）。

## 配套文件

- `scripts/mes_pull.py` — MES 全量报工拉取 + 聚合
- `scripts/build_pptx.js` — 参数化 PPTX 渲染器（14 页）
- `scripts/audit_pptx.py` — python-pptx 几何审计
- `scripts/read_docx.py` — 抽 docx 服务内容文本
- `references/mes_cli.md` — MES CLI 命令与坑
- `references/theme_classification.md` — 单标签主题优先级表
- `references/meta_schema.md` — meta.json 字段说明
- `assets/sample_meta.json` — 以 00032375（新疆银行）为范本的填充示例
