#!/usr/bin/env node
/*
 * build_pptx.js — MES 服务总结 PPT 渲染器（参数化，14 页）
 * 用法：
 *   node build_pptx.js --meta ./meta.json --data ./data.json --out ./服务总结.pptx
 * 依赖：pptxgenjs（在 scripts/ 下 `npm install`）
 */
const pptxgen = require("pptxgenjs");
const fs = require("fs");
const path = require("path");

// ---------- arg parse ----------
function getArg(name, def) {
  const i = process.argv.indexOf(name);
  return i >= 0 && i + 1 < process.argv.length ? process.argv[i + 1] : def;
}
const META = getArg("--meta", "./meta.json");
const DATA = getArg("--data", "./data.json");
const OUT = getArg("--out", null);

if (!fs.existsSync(META)) { console.error("ERROR: meta 文件不存在:", META); process.exit(1); }
if (!fs.existsSync(DATA)) { console.error("ERROR: data 文件不存在:", DATA); process.exit(1); }

const m = JSON.parse(fs.readFileSync(META, "utf8"));
let dataRaw = JSON.parse(fs.readFileSync(DATA, "utf8"));
const rawArr = Array.isArray(dataRaw) ? dataRaw : (dataRaw.records || []);
const raw = rawArr.map(d => ({
  executorName: d.executorName || "未知",
  taskTime: Number(d.taskTime || 0),
  start: (d.start || "").slice(0, 19),
  remark: d.remark || "",
  title: d.title || "",
}));

// ---------- palette ----------
const C = {
  navy: "0F2C4C", navy2: "16395F", deep: "0A1F38",
  teal: "0E9594", tealL: "3FBDB8", gold: "E0A526", goldL: "F2C75B",
  light: "F4F7FA", card: "FFFFFF", ink: "1B2A3F", mute: "5B6B7E",
  line: "DCE4EC", white: "FFFFFF",
};
const CN = "Microsoft YaHei";
const NUM = "Georgia";

// ---------- aggregate ----------
const execHours = {}, execDays = {}, execCnt = {};
const monthH = {}, monthCnt = {};
const quarterH = {};
let totalH = 0, totalN = raw.length;
for (const d of raw) {
  const nm = d.executorName || "未知";
  const tt = d.taskTime || 0;
  const st = d.start || "";
  const day = st.slice(0, 10);
  const mo = st.slice(0, 7);
  execHours[nm] = (execHours[nm] || 0) + tt;
  execDays[nm] = execDays[nm] || new Set(); if (day) execDays[nm].add(day);
  execCnt[nm] = (execCnt[nm] || 0) + 1;
  totalH += tt;
  if (mo) { monthH[mo] = (monthH[mo] || 0) + tt; monthCnt[mo] = (monthCnt[mo] || 0) + 1; }
  if (st) { const y = +st.slice(0, 4), mm = +st.slice(5, 7); const q = Math.floor((mm - 1) / 3) + 1; const k = `${y}Q${q}`; quarterH[k] = (quarterH[k] || 0) + tt; }
}
const personDays = totalH / 8;
const months = Object.keys(monthH).sort();
const monthVals = months.map(mo => +monthH[mo].toFixed(1));
const maxMonthV = Math.max(1, ...monthVals);
const monthAxis = Math.ceil((maxMonthV * 1.2) / 50) * 50;
const quarters = Object.keys(quarterH).sort();
const quarterVals = quarters.map(q => +quarterH[q].toFixed(1));

const execSorted = Object.entries(execHours).sort((a, b) => b[1] - a[1]);
const topExec = execSorted.slice(0, 6);
const topExecSum = topExec.reduce((s, e) => s + e[1], 0);
const otherExecH = totalH - topExecSum;

// theme classifier (single-label, weighted scoring -> sums to total)
// 长日志报工常一句话覆盖多件事，用"首个命中即归类"会被通用词带偏；
// 改为加权打分：strong 权重 3、normal 权重 1，取最高分主题（同分按顺序），
// 仍未命中则归入"日常支持与咨询"。每单只计一次，维度求和 = 总工时。
const THEMES = [
  { name: "故障处理与根因定位", strong: ["故障", "报错", "宕机", "崩溃", "死锁", "阻塞", "hang", "夯", "中断", "不可用", "根因", "应急处理", "修复", "异常"], normal: ["排查", "定位", "失败", "超时", "连接不上", "不一致", "损坏", "重启", "卡顿", "解锁", "锁定", "连接数"] },
  { name: "性能优化与调优", strong: ["性能", "优化", "调优", "执行计划", "全表扫描", "等待事件", "瓶颈", "top sql", "慢sql", "慢查询", "索引"], normal: ["慢", "耗时", "并发", "吞吐", "缓存", "资源", "cpu"] },
  { name: "升级迁移与改造", strong: ["迁移", "割接", "升级", "改造", "切换", "上线", "扩容", "部署", "安装", "初始化", "重构", "适配"], normal: ["替换", "搭建", "导出", "导入"] },
  { name: "备份恢复与容灾", strong: ["备份", "恢复", "rman", "容灾", "灾备", "rpo", "rto", "主备同步", "异地", "预案"], normal: ["dg", "备库"] },
  { name: "安全加固与合规", strong: ["安全", "加固", "审计", "漏洞", "合规", "等保", "脱敏", "整改", "补丁"], normal: ["权限", "加密", "扫描"] },
  { name: "定期巡检与健康管理", strong: ["巡检", "健康检查", "看护", "告警", "监控"], normal: [] },
  { name: "培训与知识沉淀", strong: ["培训", "授课", "带教", "赋能", "知识库", "手册", "规范", "最佳实践", "复盘"], normal: ["分享", "讲解", "文档", "报告", "总结", "梳理", "编写", "撰写", "整理", "归档", "笔记", "ppt"] },
  { name: "客户交流与项目管理", strong: ["会议", "汇报", "交流", "对接", "需求", "访谈", "调研", "协调", "评审", "例会", "周报", "月报"], normal: ["沟通", "讨论", "确认", "拜访", "计划"] },
  { name: "应急保障与现场值守", strong: ["值守", "结息", "年终", "结算", "重大活动", "关键时期", "重保", "活动保障", "现场保障", "旺季", "护航"], normal: ["保障", "现场支持"] },
  { name: "日常支持与咨询", strong: ["日常", "工单", "电话", "邮件", "值班", "咨询"], normal: ["支持", "在线", "运维", "维护", "纳管", "配置", "脚本", "测试", "验证"] },
];
const themeH = {};
for (const d of raw) {
  const r = ((d.remark || "") + " " + (d.title || "")).toLowerCase();
  let best = null, bestScore = 0;
  for (const th of THEMES) {
    let sc = 0;
    for (const k of th.strong) if (r.includes(k)) sc += 3;
    for (const k of th.normal) if (r.includes(k)) sc += 1;
    if (sc > bestScore) { bestScore = sc; best = th.name; }
  }
  const key = best || "日常支持与咨询";
  themeH[key] = (themeH[key] || 0) + (d.taskTime || 0);
}
const themeSorted = Object.entries(themeH).map(([n, v]) => [n, +v.toFixed(0)]).sort((a, b) => b[1] - a[1]);

function mentionCount(...ks) { let n = 0, h = 0; for (const d of raw) { const r = ((d.remark || "") + " " + (d.title || "")).toLowerCase(); if (ks.some(k => r.includes(k))) { n++; h += (d.taskTime || 0); } } return [n, h]; }
const dm = mentionCount("达梦", "dm数据库", "dm8", "rwdb");
const gs = mentionCount("高斯", "gaussdb", "高斯数据库");
const ob = mentionCount("oceanbase", "ob数据库", "ob集群", "ocp");
const gb = mentionCount("gbase");
const desen = mentionCount("脱敏");

// ---------- meta-driven fields ----------
const title = m.title || "服务总结";
const subtitle = m.subtitle || "恩墨 · 驻场运维交付报告";
const contractNo = m.contractNo || "—";
const accIds = (m.accIds || []);
const accEmpty = (m.accIdEmpty || []);
const companyName = m.companyName || "客户";
const companyId = (m.companyId != null) ? m.companyId : "—";
const pm = m.pm || "—";
const startDate = m.startDate || "";
const endDate = m.endDate || "";
const serviceScope = m.serviceScope || "（请补充服务范围说明，可来自 服务内容.docx）";
const dbStack = m.dbStack || [];
const footText = m.footText || `${companyName} ${String(startDate).split("-")[0]} 驻场服务总结 · 恩墨交付`;

const metrics = m.metrics || { n: totalN, hours: +totalH.toFixed(0), personDays: +personDays.toFixed(1), people: execSorted.length };
const hoursStr = (typeof metrics.hours === "number" ? metrics.hours.toFixed(0) : metrics.hours) + "h";
const pdStr = (typeof metrics.personDays === "number" ? metrics.personDays.toFixed(1) : metrics.personDays);
const coverStrip = [
  [String(metrics.n), "条报工"],
  [hoursStr, "总服务工时"],
  [pdStr, "人天投入"],
  [String(metrics.people), "交付工程师"],
];
const sumTiles = [
  [String(metrics.n), "条真实报工", C.teal],
  [pdStr, "折合人天(8h)", C.gold],
  [String(metrics.people), "交付工程师", C.teal],
  ["全量", "报工可追溯", C.gold],
];

const summaryLine = m.summaryLine || `以 ${pdStr} 人天投入，基于 ${metrics.n} 条真实报工，覆盖 ${dbStack.length || execSorted.length} 类技术栈，实现常态化巡检与故障根因根治。`;

// team roles (slide 5)
const top3 = execSorted.slice(0, 3);
const teamRoles = (m.teamRoles && m.teamRoles.length)
  ? m.teamRoles
  : [
      { name: top3[0] ? top3[0][0] : "", role: "主力攻坚", col: C.navy, desc: "投入最大、覆盖最广，是巡检、故障根因与迁移改造的核心力量。" },
      { name: top3[1] ? top3[1][0] : "", role: "项目统筹", col: C.teal, desc: "项目经理，例会汇报、方案制定与跨团队协调，确保交付闭环。" },
      { name: top3[2] ? top3[2][0] : "", role: "协同攻坚", col: C.gold, desc: "配合驻场攻坚，承担现场故障处理与升级迁移工作。" },
    ];
const midCount = Math.max(0, execSorted.length - 3);
const restExecH = totalH - top3.reduce((s, e) => s + e[1], 0);
const roleCards = teamRoles.concat([{ name: "中段补强", role: "多工程师协同", metric: `${midCount} 人 · 合计 ${restExecH.toFixed(0)}h`, desc: "其余工程师阶段性补强支持，弹性保障。", col: C.navy2 }]);

// tech groups (slide 7)
let techGroups = m.techGroups;
if (!techGroups) {
  const items = dbStack.length ? dbStack : ["（请补充技术栈）"];
  const cols = [[], [], []];
  items.forEach((it, i) => cols[i % 3].push(it));
  const titles = ["数据库与平台", "云管与数据平台", "运维与迁移工具"];
  const icons = ["🗄️", "☁️", "🔧"];
  const colsC = [C.navy, C.teal, C.gold];
  techGroups = titles.map((t, i) => ({ icon: icons[i], title: t, color: colsC[i], items: cols[i] }));
}

// domestic (slide 8)
let domestic = m.domesticDb;
if (!domestic) {
  if (dm[0] + gs[0] + ob[0] + gb[0] > 0) {
    domestic = [
      { name: "达梦 DM", count: dm[0] + " 条", desc: "常态化巡检、备份验证、主备同步检查全覆盖。" },
      { name: "GaussDB 高斯", count: gs[0] + " 条", desc: "部署迁移与导出导入治理。" },
      { name: "OceanBase", count: ob[0] + " 条", desc: "集群租户纳管与端口开通。" },
      { name: "GBase8s", count: gb[0] + " 条", desc: "统一运维体系协同保障。" },
    ];
  }
}

// cases / value / deliverables / sla fallbacks
const keyCases1 = m.keyCases1 || themeSorted.slice(0, 4).map(([n]) => ({ icon: "🔧", title: n, problem: "围绕该类工作持续投入", action: "形成标准化处置与知识沉淀闭环。" }));
const keyCases2 = m.keyCases2 || themeSorted.slice(0, 4).map(([n]) => ({ name: n, before: "持续投入", act: "标准处置", after: "价值沉淀" }));
const valueItems = m.valueItems || themeSorted.slice(0, 6).map(([n]) => ({ icon: "📌", title: n, desc: "围绕该维度持续投入，形成稳定交付能力。" }));
const deliverables = m.deliverables || [
  { icon: "📄", title: "数据库巡检报告", desc: "周期性健康检查与整改建议。" },
  { icon: "🔧", title: "故障分析与处置", desc: "根因定位、处理过程与预防闭环。" },
  { icon: "📊", title: "性能优化报告", desc: "性能治理结论与调优建议。" },
  { icon: "🧪", title: "迁移与脱敏", desc: "数据迁移与脱敏方案及执行记录。" },
  { icon: "📘", title: "运维规范", desc: "统一值守、巡检与应急作业标准。" },
  { icon: "☁️", title: "云管与告警", desc: "平台纳管与告警阈值治理。" },
];
const sla = m.sla || {
  response: [["一线响应", "5 分钟"], ["现场技术人员到场", "30 分钟"], ["二线 / 三线专家响应", "10 分钟"], ["7×24 紧急救援", "不限次"]],
  recovery: [["一级", "关键系统完全/部分丧失", "1h 恢复 · 24h 根因报告"], ["二级", "处理能力严重下降", "2h 恢复 · 24h 根因报告"], ["三级", "可用性受损可运行", "4h 恢复 · 48h 分析报告"], ["四级", "配置调优无业务影响", "4h 临时 · 24h 根本方案"]],
};
const nextSteps = (m.nextSteps && m.nextSteps.length) ? m.nextSteps : ["审批闭环：推动报工完成审批，固化工时资产。", "知识沉淀：将交付文档构建为可检索知识库。", "续约保障：延续驻场保障，共筑稳定运维体系。"];

console.log("records", totalN, "hours", totalH.toFixed(1), "personDays", personDays.toFixed(1));
console.log("person", execSorted.slice(0, 8).map(e => e[0] + ":" + e[1].toFixed(0)));
console.log("theme", themeSorted.map(t => t[0] + ":" + t[1]));
console.log("domestic", { dm: dm[0], gs: gs[0], ob: ob[0], gb: gb[0], desen: desen[0] });

// ---------- pres ----------
const pres = new pptxgen();
pres.layout = "LAYOUT_WIDE";
pres.author = "恩墨交付 · 台风";
pres.title = title;
const PW = 13.33, PH = 7.5;

const softShadow = () => ({ type: "outer", color: "1B2A3F", blur: 10, offset: 4, angle: 90, opacity: 0.10 });
function bgLight(slide) { slide.background = { color: C.light }; }
function bgDark(slide, color) { slide.background = { color: color || C.deep }; }

function header(slide, kicker, t) {
  slide.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.6, y: 0.52, w: 0.16, h: 0.16, rectRadius: 0.03, fill: { color: C.teal } });
  slide.addText(kicker, { x: 0.84, y: 0.45, w: 9, h: 0.3, fontFace: CN, fontSize: 12, bold: true, color: C.teal, charSpacing: 2, margin: 0, valign: "middle" });
  slide.addText(t, { x: 0.58, y: 0.86, w: 12.1, h: 0.8, fontFace: CN, fontSize: 30, bold: true, color: C.navy, margin: 0, valign: "middle" });
}
function footer(slide, n) {
  slide.addText(footText, { x: 0.6, y: 7.08, w: 9, h: 0.3, fontFace: CN, fontSize: 9, color: C.mute, margin: 0, valign: "middle" });
  slide.addText(String(n).padStart(2, "0"), { x: 12.4, y: 7.08, w: 0.5, h: 0.3, fontFace: NUM, fontSize: 10, color: C.mute, align: "right", margin: 0, valign: "middle" });
}
function card(slide, x, y, w, h, fill) {
  slide.addShape(pres.shapes.RECTANGLE, { x, y, w, h, fill: { color: fill || C.card }, line: { color: C.line, width: 1 }, shadow: softShadow() });
  slide.addShape(pres.shapes.RECTANGLE, { x, y, w: 0.08, h, fill: { color: C.teal } });
}

const accLine = "子项 " + accIds.join(" / ") + (accEmpty.length ? "   （" + accEmpty.join(" / ") + " 暂无报工）" : "");

// 合同子项投入页（可选；由 meta.subItems 驱动）
const subItems = (m.subItems && m.subItems.length) ? m.subItems : null;

// 页码计数器（页面增删后页码自动连续）
let PAGE = 1;

// ================= Slide 1 : Cover =================
(function () {
  const s = pres.addSlide(); bgDark(s, C.deep);
  s.addShape(pres.shapes.OVAL, { x: 9.7, y: -1.6, w: 5.6, h: 5.6, fill: { color: C.navy2, transparency: 35 }, line: { type: "none" } });
  s.addShape(pres.shapes.OVAL, { x: 10.7, y: -0.6, w: 3.6, h: 3.6, fill: { color: C.teal, transparency: 60 }, line: { type: "none" } });
  s.addShape(pres.shapes.OVAL, { x: 11.4, y: 0.1, w: 2.2, h: 2.2, fill: { color: C.gold, transparency: 55 }, line: { type: "none" } });
  s.addShape(pres.shapes.RECTANGLE, { x: 0.9, y: 2.05, w: 0.12, h: 2.0, fill: { color: C.gold } });
  s.addText("驻场服务总结报告", { x: 1.2, y: 2.05, w: 8, h: 0.4, fontFace: CN, fontSize: 15, bold: true, color: C.tealL, charSpacing: 3, margin: 0 });
  s.addText(title, { x: 1.18, y: 2.45, w: 10.6, h: 1.9, fontFace: CN, fontSize: 36, bold: true, color: C.white, lineSpacingMultiple: 1.05, margin: 0 });
  s.addText(subtitle, { x: 1.2, y: 4.4, w: 10.8, h: 0.5, fontFace: CN, fontSize: 14, color: "C7D6E5", margin: 0 });
  s.addShape(pres.shapes.RECTANGLE, { x: 1.2, y: 5.05, w: 10.8, h: 0.02, fill: { color: "33485F" }, line: { type: "none" } });
  s.addText([
    { text: "合同号 " + contractNo, options: { fontFace: CN, fontSize: 12, color: "9FB4C9", breakLine: false } },
    { text: "     " + accLine, options: { fontFace: CN, fontSize: 12, color: "9FB4C9", breakLine: false } },
  ], { x: 1.2, y: 5.2, w: 11.6, h: 0.35, margin: 0 });
  s.addText(`客户：${companyName}（公司 ID ${companyId}）   ·   项目经理 ${pm}   ·   服务周期 ${startDate} 起（数据截至 ${endDate}）`, { x: 1.2, y: 5.58, w: 11.6, h: 0.35, fontFace: CN, fontSize: 12, color: "9FB4C9", margin: 0 });
  let sx = 1.2;
  coverStrip.forEach(([v, l]) => {
    s.addText(v, { x: sx, y: 6.25, w: 2.7, h: 0.5, fontFace: NUM, fontSize: 26, bold: true, color: C.goldL, margin: 0 });
    s.addText(l, { x: sx, y: 6.75, w: 2.7, h: 0.3, fontFace: CN, fontSize: 11, color: "9FB4C9", margin: 0 });
    sx += 2.7;
  });
})();

// ================= Slide 2 : 核心结论 =================
(function () {
  const s = pres.addSlide(); bgLight(s);
  header(s, "EXECUTIVE SUMMARY · 核心结论", "一页看懂：我们交付了什么价值");
  card(s, 0.6, 1.95, 12.13, 1.7, C.navy);
  s.addShape(pres.shapes.RECTANGLE, { x: 0.6, y: 1.95, w: 0.08, h: 1.7, fill: { color: C.gold } });
  s.addText(summaryLine, { x: 0.95, y: 2.15, w: 11.4, h: 1.3, valign: "middle", margin: 0, fontFace: CN, fontSize: 18, color: C.white, lineSpacingMultiple: 1.15 });
  const tw = 2.86, gap = 0.23, ty = 4.05, th = 2.55;
  let tx = 0.6;
  sumTiles.forEach(([v, l, col]) => {
    card(s, tx, ty, tw, th, C.card);
    s.addShape(pres.shapes.RECTANGLE, { x: tx, y: ty, w: tw, h: 0.1, fill: { color: col } });
    s.addText(v, { x: tx, y: ty + 0.55, w: tw, h: 1.0, fontFace: NUM, fontSize: 38, bold: true, color: C.navy, align: "center", margin: 0 });
    s.addText(l, { x: tx, y: ty + 1.65, w: tw, h: 0.6, fontFace: CN, fontSize: 15, color: C.mute, align: "center", margin: 0 });
    tx += tw + gap;
  });
  footer(s, ++PAGE);
})();

// ================= Slide 3 : 项目概况 =================
(function () {
  const s = pres.addSlide(); bgLight(s);
  header(s, "PROJECT OVERVIEW · 项目概况", "这是什么项目：多库异构驻场运维保障");
  card(s, 0.6, 1.95, 5.0, 4.6, C.card);
  s.addText("项目定位与服务范围", { x: 0.85, y: 2.15, w: 4.5, h: 0.4, fontFace: CN, fontSize: 16, bold: true, color: C.teal, margin: 0 });
  s.addText(serviceScope, { x: 0.85, y: 2.6, w: 4.5, h: 3.7, valign: "top", margin: 0, fontFace: CN, fontSize: 13.5, color: C.ink, lineSpacingMultiple: 1.12 });
  const kpis = [
    [String(metrics.n), "报工条数"],
    [hoursStr, "总服务工时"],
    [pdStr, "折合人天(8h)"],
    [String(months.length || 1), "服务月数"],
    [String(metrics.people), "交付工程师"],
    [String(companyId), "客户公司 ID"],
  ];
  const gw = 2.18, gh = 1.4, gx0 = 5.85, gy0 = 1.95, ggx = 0.22, ggy = 0.2;
  kpis.forEach(([v, l], i) => {
    const cx = gx0 + (i % 3) * (gw + ggx);
    const cy = gy0 + Math.floor(i / 3) * (gh + ggy);
    card(s, cx, cy, gw, gh, C.navy);
    s.addText(v, { x: cx, y: cy + 0.22, w: gw, h: 0.7, fontFace: NUM, fontSize: 28, bold: true, color: C.goldL, align: "center", margin: 0 });
    s.addText(l, { x: cx, y: cy + 0.92, w: gw, h: 0.4, fontFace: CN, fontSize: 12.5, color: "C7D6E5", align: "center", margin: 0 });
  });
  footer(s, ++PAGE);
})();

// ================= Slide 3.5 : 合同子项与工时结构（可选） =================
if (subItems) {
  (function () {
    const s = pres.addSlide(); bgLight(s);
    header(s, "CONTRACT SUB-ITEMS · 合同子项投入", "合同子项按形态分工：驻场 + 人天为主力投入");
    const cw = 3.94, ch = 2.18, gx = 0.6, gy = 1.95, gpx = 0.2, gpy = 0.18;
    const dcols = [C.navy, C.teal, C.gold, C.navy2, C.teal, C.navy];
    subItems.slice(0, 6).forEach((it, i) => {
      const x = gx + (i % 3) * (cw + gpx);
      const y = gy + Math.floor(i / 3) * (ch + gpy);
      const col = dcols[i % dcols.length];
      const actual = (it.actual != null ? it.actual : 0);
      const plan = (it.plan != null ? it.plan : null);
      const share = totalH ? Math.round((actual / totalH) * 100) : 0;
      card(s, x, y, cw, ch, C.card);
      s.addShape(pres.shapes.RECTANGLE, { x, y, w: cw, h: 0.1, fill: { color: col } });
      s.addText(it.name || "", { x: x + 0.3, y: y + 0.24, w: cw - 0.6, h: 0.4, fontFace: CN, fontSize: 15, bold: true, color: C.navy, valign: "middle", margin: 0 });
      s.addText(it.type || "", { x: x + 0.3, y: y + 0.64, w: cw - 0.6, h: 0.28, fontFace: CN, fontSize: 10.5, color: col, margin: 0 });
      s.addText([
        { text: String(actual), options: { fontFace: NUM, fontSize: 30, bold: true, color: C.navy } },
        { text: "h", options: { fontFace: CN, fontSize: 12, color: C.mute } },
      ], { x: x + 0.3, y: y + 0.98, w: cw - 0.6, h: 0.55, valign: "middle", margin: 0 });
      s.addText(`计划 ${plan != null ? plan : "—"}h · 占比 ${share}%`, { x: x + 0.3, y: y + 1.55, w: cw - 0.6, h: 0.28, fontFace: CN, fontSize: 11, color: C.mute, margin: 0 });
      s.addText(it.id || "", { x: x + 0.3, y: y + 1.84, w: cw - 0.6, h: 0.24, fontFace: NUM, fontSize: 9, color: "B8C4D0", margin: 0 });
    });
    footer(s, ++PAGE);
  })();
}

// ================= Slide 4 : 投入节奏 =================
(function () {
  const s = pres.addSlide(); bgLight(s);
  header(s, "INVESTMENT RHYTHM · 投入节奏", "投入节奏：月度工时分布与关键特征");
  s.addChart(pres.charts.BAR, [{ name: "月度工时(h)", labels: months, values: monthVals }], {
    x: 0.6, y: 2.0, w: 8.7, h: 4.6, barDir: "col",
    chartColors: [C.teal],
    chartArea: { fill: { color: C.light } }, plotArea: { fill: { color: C.light } },
    catAxisLabelColor: C.mute, catAxisLabelFontFace: CN, catAxisLabelFontSize: 9,
    valAxisLabelColor: C.mute, valAxisLabelFontFace: CN, valAxisLabelFontSize: 9,
    valGridLine: { color: C.line, size: 0.5 }, catGridLine: { style: "none" },
    showValue: false, showLegend: false, barGapWidthPct: 45,
    valAxisMaxVal: monthAxis, valAxisMinVal: 0,
  });
  const peakMo = months[monthVals.indexOf(maxMonthV)] || "—";
  const avg = months.length ? (totalH / months.length).toFixed(0) : "0";
  card(s, 9.55, 2.0, 3.18, 4.6, C.card);
  s.addText("节奏特征", { x: 9.8, y: 2.2, w: 2.7, h: 0.4, fontFace: CN, fontSize: 15, bold: true, color: C.teal, margin: 0 });
  s.addText([
    { text: "高峰 ", options: { fontFace: CN, fontSize: 13, color: C.ink, bold: true } },
    { text: `${peakMo} 达 ${maxMonthV.toFixed(0)}h`, options: { fontFace: CN, fontSize: 13, color: C.gold, bold: true, breakLine: true } },
    { text: "项目快速爬坡至满负荷保障，单月峰值显著。", options: { fontFace: CN, fontSize: 12.5, color: C.mute, breakLine: true, paraSpaceAfter: 10 } },
    { text: "稳定 ", options: { fontFace: CN, fontSize: 13, color: C.ink, bold: true } },
    { text: `月均约 ${avg}h`, options: { fontFace: CN, fontSize: 13, color: C.gold, bold: true, breakLine: true } },
    { text: "各月波动平缓，体现持续稳定驻场。", options: { fontFace: CN, fontSize: 12.5, color: C.mute, breakLine: true, paraSpaceAfter: 10 } },
    { text: "连续性", options: { fontFace: CN, fontSize: 13, color: C.ink, bold: true, breakLine: true } },
    { text: `${months.length} 个月无长期断档，保障不中断。`, options: { fontFace: CN, fontSize: 12.5, color: C.mute } },
  ], { x: 9.8, y: 2.7, w: 2.75, h: 3.7, valign: "top", margin: 0, lineSpacingMultiple: 1.05 });
  footer(s, ++PAGE);
})();

// ================= Slide 5 : 人员投入结构 =================
(function () {
  const s = pres.addSlide(); bgLight(s);
  header(s, "TEAM STRUCTURE · 人员投入", "主力攻坚 + 项目统筹 + 协同补强");
  const labels = topExec.map(e => e[0]);
  const values = topExec.map(e => +e[1].toFixed(0));
  labels.push("其他补强"); values.push(+otherExecH.toFixed(0));
  s.addChart(pres.charts.DOUGHNUT, [{ name: "人员占比", labels, values }], {
    x: 0.4, y: 1.9, w: 5.8, h: 4.8,
    chartColors: [C.navy, C.teal, C.gold, C.tealL, C.navy2, C.mute, "B8C4D0"],
    holeSize: 60, showLegend: true, legendPos: "b", legendColor: C.ink, legendFontFace: CN, legendFontSize: 11,
    showPercent: true, dataLabelColor: "FFFFFF", dataLabelFontFace: CN, dataLabelFontSize: 11, dataLabelFontBold: true,
    showValue: false,
  });
  s.addText([{ text: totalH.toFixed(0), options: { fontFace: NUM, fontSize: 24, bold: true, color: C.navy } }, { text: "h", options: { fontFace: CN, fontSize: 12, color: C.mute } }],
    { x: 1.4, y: 3.85, w: 3.8, h: 0.5, align: "center", margin: 0 });
  s.addText("合计工时", { x: 1.4, y: 4.35, w: 3.8, h: 0.3, align: "center", fontFace: CN, fontSize: 11, color: C.mute, margin: 0 });
  const rx = 6.4, rw = 6.33, rh = 1.06, ry0 = 1.95, rgap = 0.14;
  roleCards.forEach((rc, i) => {
    const nm = rc.name, role = rc.role, metric = rc.metric, desc = rc.desc, col = rc.col;
    const ry = ry0 + i * (rh + rgap);
    const name = nm || "—";
    const metr = metric || `${execHours[name] ? execHours[name].toFixed(0) : "0"}h · ${execDays[name] ? execDays[name].size : 0} 天 · ${execCnt[name] || 0} 条`;
    card(s, rx, ry, rw, rh, C.card);
    s.addShape(pres.shapes.OVAL, { x: rx + 0.28, y: ry + 0.18, w: 0.7, h: 0.7, fill: { color: col } });
    s.addText(name[0] || "·", { x: rx + 0.28, y: ry + 0.18, w: 0.7, h: 0.7, align: "center", valign: "middle", fontFace: CN, fontSize: 20, bold: true, color: "FFFFFF", margin: 0 });
    s.addText(role, { x: rx + 1.15, y: ry + 0.14, w: 3, h: 0.35, fontFace: CN, fontSize: 15, bold: true, color: C.navy, margin: 0 });
    s.addText(metr, { x: rx + 1.15, y: ry + 0.5, w: 5, h: 0.3, fontFace: CN, fontSize: 11, color: col, bold: true, margin: 0 });
    s.addText(desc, { x: rx + 1.15, y: ry + 0.78, w: 5.0, h: 0.25, fontFace: CN, fontSize: 10.5, color: C.mute, margin: 0 });
  });
  footer(s, ++PAGE);
})();

// ================= Slide 6 : 服务内容体系 =================
(function () {
  const s = pres.addSlide(); bgLight(s);
  header(s, "SERVICE SYSTEM · 服务内容体系", "十大工作维度，全面覆盖运维保障");
  const labels = themeSorted.map(t => t[0]);
  const vals = themeSorted.map(t => t[1]);
  s.addChart(pres.charts.BAR, [{ name: "维度工时(h)", labels, values: vals }], {
    x: 0.6, y: 2.0, w: 8.6, h: 4.6, barDir: "bar",
    chartColors: [C.teal],
    chartArea: { fill: { color: C.light } }, plotArea: { fill: { color: C.light } },
    catAxisLabelColor: C.ink, catAxisLabelFontFace: CN, catAxisLabelFontSize: 11,
    valAxisLabelColor: C.mute, valAxisLabelFontFace: CN, valAxisLabelFontSize: 9,
    valGridLine: { color: C.line, size: 0.5 }, catGridLine: { style: "none" },
    showValue: true, dataLabelColor: C.navy, dataLabelFontFace: CN, dataLabelFontSize: 10, dataLabelPosition: "outEnd",
    showLegend: false, barGapWidthPct: 40,
  });
  card(s, 9.5, 2.0, 3.23, 4.6, C.card);
  s.addText("结构洞察", { x: 9.75, y: 2.2, w: 2.7, h: 0.4, fontFace: CN, fontSize: 15, bold: true, color: C.teal, margin: 0 });
  const top3t = themeSorted.slice(0, 3).map(t => t[0]);
  s.addText([
    { text: "核心方向", options: { fontFace: CN, fontSize: 13, bold: true, color: C.navy, breakLine: true } },
    { text: `${top3t.join(" / ")} 三类合计占主要工时，是日常价值最密集的方向。`, options: { fontFace: CN, fontSize: 12.5, color: C.mute, breakLine: true, paraSpaceAfter: 10 } },
    { text: "稳定底座", options: { fontFace: CN, fontSize: 13, bold: true, color: C.navy, breakLine: true } },
    { text: "巡检 + 备份 + 容灾构成稳定运行的底座，保障数据库常态健康。", options: { fontFace: CN, fontSize: 12.5, color: C.mute, breakLine: true, paraSpaceAfter: 10 } },
    { text: "体系能力", options: { fontFace: CN, fontSize: 13, bold: true, color: C.navy, breakLine: true } },
    { text: "培训 + 应急 + 安全体现知识沉淀、关键时期保障与合规加固。", options: { fontFace: CN, fontSize: 12.5, color: C.mute } },
  ], { x: 9.75, y: 2.7, w: 2.75, h: 3.7, valign: "top", margin: 0, lineSpacingMultiple: 1.05 });
  footer(s, ++PAGE);
})();

// ================= Slide 7 : 技术栈与纳管范围 =================
(function () {
  const s = pres.addSlide(); bgLight(s);
  header(s, "TECH STACK · 技术栈与纳管范围", "Oracle + 国产数据库 + 云管平台");
  const gx0 = 0.6, gy = 2.0, gw = 3.94, gh = 4.5, ggap = 0.2;
  techGroups.slice(0, 3).forEach((g, i) => {
    const ic = g.icon, t = g.title, col = g.color, items = g.items || [];
    const x = gx0 + i * (gw + ggap);
    card(s, x, gy, gw, gh, C.card);
    s.addShape(pres.shapes.RECTANGLE, { x, y: gy, w: gw, h: 0.1, fill: { color: col } });
    s.addText(ic, { x: x + 0.3, y: gy + 0.3, w: 0.8, h: 0.7, fontSize: 28, margin: 0 });
    s.addText(t, { x: x + 1.15, y: gy + 0.35, w: gw - 1.3, h: 0.6, fontFace: CN, fontSize: 15, bold: true, color: C.navy, valign: "middle", margin: 0, lineSpacingMultiple: 0.95 });
    let by = gy + 1.18;
    items.forEach(it => {
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: x + 0.3, y: by, w: gw - 0.6, h: 0.5, rectRadius: 0.06, fill: { color: C.light }, line: { color: C.line, width: 1 } });
      s.addShape(pres.shapes.OVAL, { x: x + 0.45, y: by + 0.18, w: 0.14, h: 0.14, fill: { color: col }, line: { type: "none" } });
      s.addText(it, { x: x + 0.7, y: by, w: gw - 1.0, h: 0.5, fontFace: CN, fontSize: 12.5, color: C.ink, valign: "middle", margin: 0 });
      by += 0.52;
    });
  });
  footer(s, ++PAGE);
})();

// ================= Slide 8 : 国产数据库服务专项 =================
(function () {
  const s = pres.addSlide(); bgLight(s);
  const domNames = (domestic && domestic.length) ? domestic.map(d => d.name).slice(0, 3).join(" / ") : "国产数据库";
  header(s, "DOMESTIC DATABASE · 国产数据库服务专项", domNames + " 深度保障");
  if (domestic && domestic.length) {
    const domTop = [["达梦", dm[0]], ["OceanBase", ob[0]], ["GaussDB", gs[0]], ["GBase8s", gb[0]]].sort((a, b) => b[1] - a[1]);
    const strip = [
      [domestic.length + "类", "国产库覆盖", C.teal],
      [String(domTop[0][1]), domTop[0][0] + " 报工", C.navy],
      [String(domTop[1][1]), domTop[1][0] + " 报工", C.gold],
      ["配合原厂", "根因定位", C.navy2],
    ];
    const sw = 2.86, sgap = 0.23, sy = 1.92, sh = 1.05;
    let sx = 0.6;
    strip.forEach(([v, l, col]) => {
      card(s, sx, sy, sw, sh, C.card);
      s.addShape(pres.shapes.RECTANGLE, { x: sx, y: sy, w: sw, h: 0.08, fill: { color: col } });
      s.addText(v, { x: sx + 0.2, y: sy + 0.16, w: sw - 0.4, h: 0.5, fontFace: CN, fontSize: 19, bold: true, color: col, margin: 0 });
      s.addText(l, { x: sx + 0.2, y: sy + 0.66, w: sw - 0.4, h: 0.32, fontFace: CN, fontSize: 11, color: C.mute, margin: 0 });
      sx += sw + sgap;
    });
    const cw = 2.86, ch = 2.05, gx = 0.6, gy = 3.12, gpx = 0.23;
    const dcols = [C.navy, C.teal, C.gold, C.navy2];
    domestic.forEach((db, i) => {
      const t = db.name, cnt = db.count, d = db.desc;
      const col = dcols[i % dcols.length];
      const x = gx + i * (cw + gpx);
      card(s, x, gy, cw, ch, C.card);
      s.addShape(pres.shapes.RECTANGLE, { x, y: gy, w: cw, h: 0.08, fill: { color: col } });
      s.addText("🟦", { x: x + 0.25, y: gy + 0.22, w: 0.7, h: 0.6, fontSize: 24, margin: 0 });
      s.addText(t, { x: x + 1.0, y: gy + 0.22, w: cw - 1.1, h: 0.55, fontFace: CN, fontSize: 16, bold: true, color: C.navy, valign: "middle", margin: 0 });
      s.addText(cnt, { x: x + 0.25, y: gy + 0.85, w: cw - 0.5, h: 0.3, fontFace: CN, fontSize: 12, bold: true, color: col, margin: 0 });
      s.addText(d, { x: x + 0.25, y: gy + 1.18, w: cw - 0.5, h: 0.8, fontFace: CN, fontSize: 11.5, color: C.mute, valign: "top", margin: 0, lineSpacingMultiple: 1.05 });
    });
    card(s, 0.6, 5.35, 12.13, 1.45, C.navy);
    s.addShape(pres.shapes.RECTANGLE, { x: 0.6, y: 5.35, w: 0.08, h: 1.45, fill: { color: C.gold } });
    s.addText("国产库专项成效", { x: 0.9, y: 5.5, w: 4, h: 0.35, fontFace: CN, fontSize: 14, bold: true, color: C.goldL, margin: 0 });
    const domParts = [["达梦", dm[0]], ["GaussDB", gs[0]], ["OceanBase", ob[0]], ["GBase8s", gb[0]]].filter(x => x[1] > 0).map(x => `${x[0]} ${x[1]} 条`);
    s.addText([
      { text: `${domParts.join("、")}报工，配合原厂完成迁移、性能与主备同步等根因定位；`, options: { fontFace: CN, fontSize: 12, color: "DCE6F0", bullet: { code: "2022" }, breakLine: true, paraSpaceAfter: 4 } },
      { text: `形成国产库运维方法论与最佳实践，支撑信创替代平稳落地。`, options: { fontFace: CN, fontSize: 12, color: "DCE6F0", bullet: { code: "2022" } } },
    ], { x: 0.9, y: 5.85, w: 11.6, h: 0.85, valign: "top", margin: 0, lineSpacingMultiple: 1.05 });
  } else {
    card(s, 0.6, 2.2, 12.13, 3.6, C.card);
    s.addText("本服务以 Oracle 为主", { x: 0.9, y: 2.5, w: 11, h: 0.6, fontFace: CN, fontSize: 22, bold: true, color: C.navy, margin: 0 });
    s.addText("报工文本中国产库关键词命中为 0，国产库保障详情见「技术栈与纳管范围」页。若需突出国产库专项，请在 meta.domesticDb 中手工补充达梦/GaussDB/OceanBase/GBase 的覆盖套数与典型工作。", { x: 0.9, y: 3.2, w: 11, h: 2.0, fontFace: CN, fontSize: 14, color: C.mute, valign: "top", margin: 0, lineSpacingMultiple: 1.15 });
  }
  footer(s, ++PAGE);
})();

// ================= Slide 9 : 技术攻关(一) 故障根因与关键时期保障 =================
(function () {
  const s = pres.addSlide(); bgLight(s);
  header(s, "KEY CASES ① · 故障根因与关键时期保障", "把生产隐患由未知突发变为可预判");
  const cw = 5.95, ch = 2.1, gx = 0.6, gy = 1.98, gpx = 0.23, gpy = 0.22;
  keyCases1.slice(0, 4).forEach((kc, i) => {
    const ic = kc.icon, t = kc.title, p = kc.problem, a = kc.action;
    const x = gx + (i % 2) * (cw + gpx);
    const y = gy + Math.floor(i / 2) * (ch + gpy);
    card(s, x, y, cw, ch, C.card);
    s.addText(ic || "🔧", { x: x + 0.3, y: y + 0.25, w: 0.8, h: 0.7, fontSize: 28, margin: 0 });
    s.addText(t, { x: x + 1.15, y: y + 0.28, w: cw - 1.4, h: 0.55, fontFace: CN, fontSize: 16, bold: true, color: C.navy, valign: "middle", margin: 0 });
    s.addText([{ text: "问题  ", options: { fontFace: CN, fontSize: 11.5, bold: true, color: C.gold } }, { text: p, options: { fontFace: CN, fontSize: 11.5, color: C.ink } }],
      { x: x + 0.3, y: y + 0.95, w: cw - 0.6, h: 0.55, valign: "top", margin: 0, lineSpacingMultiple: 1.05 });
    s.addShape(pres.shapes.RECTANGLE, { x: x + 0.3, y: y + 1.5, w: cw - 0.6, h: 0.012, fill: { color: C.line }, line: { type: "none" } });
    s.addText([{ text: "结果  ", options: { fontFace: CN, fontSize: 11.5, bold: true, color: C.teal } }, { text: a, options: { fontFace: CN, fontSize: 11.5, color: C.ink } }],
      { x: x + 0.3, y: y + 1.62, w: cw - 0.6, h: 0.45, valign: "top", margin: 0, lineSpacingMultiple: 1.05 });
  });
  footer(s, ++PAGE);
})();

// ================= Slide 10 : 技术攻关(二) 性能优化与迁移 =================
(function () {
  const s = pres.addSlide(); bgLight(s);
  header(s, "KEY CASES ② · 性能优化与迁移", "性能治理 + 数据迁移双线推进");
  const cw = 5.95, ch = 2.1, gx = 0.6, gy = 1.98, gapx = 0.23, gapy = 0.22;
  keyCases2.slice(0, 4).forEach((kc, i) => {
    const name = kc.name, before = kc.before, act = kc.act, after = kc.after;
    const x = gx + (i % 2) * (cw + gapx);
    const y = gy + Math.floor(i / 2) * (ch + gapy);
    card(s, x, y, cw, ch, C.card);
    s.addText(name, { x: x + 0.35, y: y + 0.25, w: cw - 0.7, h: 0.5, fontFace: CN, fontSize: 16, bold: true, color: C.navy, margin: 0 });
    s.addText(before, { x: x + 0.35, y: y + 0.85, w: 2.1, h: 0.7, fontFace: CN, fontSize: 14, bold: true, color: C.mute, align: "center", valign: "middle", margin: 0 });
    s.addText("→", { x: x + 2.45, y: y + 0.9, w: 0.7, h: 0.6, fontFace: CN, fontSize: 22, bold: true, color: C.teal, align: "center", margin: 0 });
    s.addText(after, { x: x + 3.15, y: y + 0.85, w: 1.9, h: 0.7, fontFace: CN, fontSize: 14, bold: true, color: C.navy, align: "center", valign: "middle", margin: 0 });
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: x + 4.75, y: y + 0.95, w: 1.0, h: 0.5, rectRadius: 0.08, fill: { color: C.gold } });
    s.addText(act, { x: x + 4.7, y: y + 0.95, w: 1.1, h: 0.5, fontFace: CN, fontSize: 11, bold: true, color: "FFFFFF", align: "center", valign: "middle", margin: 0 });
    s.addText("优化前", { x: x + 0.35, y: y + 1.55, w: 2.1, h: 0.3, fontFace: CN, fontSize: 10, color: C.mute, align: "center", margin: 0 });
    s.addText("优化后", { x: x + 3.15, y: y + 1.55, w: 1.9, h: 0.3, fontFace: CN, fontSize: 10, color: C.mute, align: "center", margin: 0 });
  });
  footer(s, ++PAGE);
})();

// ================= Slide 11 : 价值体现 =================
(function () {
  const s = pres.addSlide(); bgLight(s);
  header(s, "VALUE DELIVERED · 价值体现", "把技术动作翻译成六类业务价值");
  const cw = 3.94, ch = 2.18, gx = 0.6, gy = 1.98, gpx = 0.2, gpy = 0.18;
  valueItems.slice(0, 6).forEach((v, i) => {
    const ic = v.icon, t = v.title, d = v.desc, col = v.col || C.teal;
    const x = gx + (i % 3) * (cw + gpx);
    const y = gy + Math.floor(i / 3) * (ch + gpy);
    card(s, x, y, cw, ch, C.card);
    s.addShape(pres.shapes.RECTANGLE, { x, y, w: cw, h: 0.1, fill: { color: col } });
    s.addText(ic || "📌", { x: x + 0.3, y: y + 0.28, w: 0.7, h: 0.6, fontSize: 26, margin: 0 });
    s.addText(t, { x: x + 1.05, y: y + 0.32, w: cw - 1.3, h: 0.5, fontFace: CN, fontSize: 16, bold: true, color: C.navy, valign: "middle", margin: 0 });
    s.addText(d, { x: x + 0.3, y: y + 1.05, w: cw - 0.6, h: 1.0, fontFace: CN, fontSize: 12.5, color: C.mute, valign: "top", margin: 0, lineSpacingMultiple: 1.08 });
  });
  footer(s, ++PAGE);
})();

// ================= Slide 12 : 交付成果物 =================
(function () {
  const s = pres.addSlide(); bgLight(s);
  header(s, "DELIVERABLES · 交付成果物", "驻场服务沉淀的可交付资产");
  const cw = 3.94, ch = 2.18, gx = 0.6, gy = 1.98, gpx = 0.2, gpy = 0.18;
  deliverables.slice(0, 6).forEach((dl, i) => {
    const ic = dl.icon, t = dl.title, d = dl.desc;
    const x = gx + (i % 3) * (cw + gpx);
    const y = gy + Math.floor(i / 3) * (ch + gpy);
    card(s, x, y, cw, ch, C.card);
    s.addShape(pres.shapes.OVAL, { x: x + 0.3, y: y + 0.38, w: 0.9, h: 0.9, fill: { color: C.light }, line: { color: C.teal, width: 1.5 } });
    s.addText(ic || "📄", { x: x + 0.3, y: y + 0.38, w: 0.9, h: 0.9, align: "center", valign: "middle", fontSize: 28, margin: 0 });
    s.addText(t, { x: x + 1.35, y: y + 0.4, w: cw - 1.6, h: 0.5, fontFace: CN, fontSize: 16, bold: true, color: C.navy, valign: "middle", margin: 0 });
    s.addText(d, { x: x + 1.35, y: y + 0.92, w: cw - 1.6, h: 1.0, fontFace: CN, fontSize: 12, color: C.mute, valign: "top", margin: 0, lineSpacingMultiple: 1.08 });
  });
  footer(s, ++PAGE);
})();

// ================= Slide 13 : 服务水平承诺达成 =================
(function () {
  const s = pres.addSlide(); bgLight(s);
  header(s, "SLA · 服务水平承诺达成", "响应与恢复标准严格落地");
  card(s, 0.6, 1.95, 6.0, 4.6, C.card);
  s.addText("事件响应与到场标准", { x: 0.85, y: 2.15, w: 5.5, h: 0.4, fontFace: CN, fontSize: 16, bold: true, color: C.teal, margin: 0 });
  let ry = 2.65;
  (sla.response || []).forEach(([k, v]) => {
    s.addShape(pres.shapes.RECTANGLE, { x: 0.85, y: ry, w: 5.5, h: 0.62, fill: { color: C.light }, line: { color: C.line, width: 1 } });
    s.addText(k, { x: 1.05, y: ry, w: 3.6, h: 0.62, fontFace: CN, fontSize: 14, color: C.ink, valign: "middle", margin: 0 });
    s.addText(v, { x: 4.5, y: ry, w: 1.8, h: 0.62, fontFace: CN, fontSize: 15, bold: true, color: C.navy, align: "right", valign: "middle", margin: 0 });
    ry += 0.72;
  });
  s.addText("驻场工程师工作时段现场处理；非工作时段按到场时限要求执行。", { x: 0.85, y: 5.65, w: 5.5, h: 0.7, fontFace: CN, fontSize: 11.5, color: C.mute, valign: "top", margin: 0, lineSpacingMultiple: 1.05 });
  card(s, 6.83, 1.95, 5.9, 4.6, C.card);
  s.addText("分级恢复时限", { x: 7.08, y: 2.15, w: 5.4, h: 0.4, fontFace: CN, fontSize: 16, bold: true, color: C.teal, margin: 0 });
  let ly = 2.65;
  (sla.recovery || []).forEach(([lv, desc, sl], i) => {
    const col = i === 0 ? C.gold : C.navy;
    s.addShape(pres.shapes.RECTANGLE, { x: 7.08, y: ly, w: 5.4, h: 0.82, fill: { color: C.light }, line: { color: C.line, width: 1 } });
    s.addShape(pres.shapes.RECTANGLE, { x: 7.08, y: ly, w: 0.9, h: 0.82, fill: { color: col } });
    s.addText(lv, { x: 7.08, y: ly, w: 0.9, h: 0.82, align: "center", valign: "middle", fontFace: CN, fontSize: 16, bold: true, color: "FFFFFF", margin: 0 });
    s.addText(desc, { x: 8.1, y: ly + 0.08, w: 4.2, h: 0.38, fontFace: CN, fontSize: 12, color: C.ink, valign: "middle", margin: 0 });
    s.addText(sl, { x: 8.1, y: ly + 0.42, w: 4.2, h: 0.34, fontFace: CN, fontSize: 11.5, bold: true, color: C.teal, valign: "middle", margin: 0 });
    ly += 0.92;
  });
  footer(s, ++PAGE);
})();

// ================= Slide 14 : 总结与展望 =================
(function () {
  const s = pres.addSlide(); bgDark(s, C.deep);
  s.addShape(pres.shapes.OVAL, { x: -1.8, y: 4.8, w: 5.2, h: 5.2, fill: { color: C.navy2, transparency: 45 }, line: { type: "none" } });
  s.addShape(pres.shapes.OVAL, { x: 10.5, y: -1.8, w: 4.5, h: 4.5, fill: { color: C.teal, transparency: 70 }, line: { type: "none" } });
  s.addShape(pres.shapes.RECTANGLE, { x: 0.9, y: 0.75, w: 0.12, h: 0.55, fill: { color: C.gold } });
  s.addText("SUMMARY & OUTLOOK · 总结与展望", { x: 1.2, y: 0.7, w: 10, h: 0.4, fontFace: CN, fontSize: 13, bold: true, color: C.tealL, charSpacing: 2, margin: 0 });
  s.addText("交付成效显著，建议延续保障", { x: 1.18, y: 1.1, w: 11, h: 0.7, fontFace: CN, fontSize: 30, bold: true, color: C.white, margin: 0 });
  s.addText("核心成效", { x: 0.9, y: 2.2, w: 5.5, h: 0.4, fontFace: CN, fontSize: 17, bold: true, color: C.goldL, margin: 0 });
  s.addText([
    { text: `${months.length} 个月、${pdStr} 人天投入，${metrics.n} 条真实报工全程可追溯。`, options: { fontFace: CN, fontSize: 14, color: "DCE6F0", bullet: { code: "2022" }, breakLine: true, paraSpaceAfter: 10 } },
    { text: `覆盖 ${dbStack.length || execSorted.length} 类技术栈，含 Oracle 与国产数据库（达梦/GaussDB/OceanBase）。`, options: { fontFace: CN, fontSize: 14, color: "DCE6F0", bullet: { code: "2022" }, breakLine: true, paraSpaceAfter: 10 } },
    { text: "故障根因根治、关键时期现场值守，保障零事故稳定运行。", options: { fontFace: CN, fontSize: 14, color: "DCE6F0", bullet: { code: "2022" } } },
  ], { x: 0.9, y: 2.7, w: 5.7, h: 3.5, valign: "top", margin: 0, lineSpacingMultiple: 1.1 });
  s.addShape(pres.shapes.RECTANGLE, { x: 7.0, y: 2.1, w: 5.7, h: 4.2, fill: { color: C.navy2 }, line: { color: "33485F", width: 1 } });
  s.addText("下一步行动", { x: 7.3, y: 2.35, w: 5, h: 0.4, fontFace: CN, fontSize: 17, bold: true, color: C.goldL, margin: 0 });
  let ny = 2.85;
  nextSteps.slice(0, 3).forEach(step => {
    const idx = nextSteps.indexOf(step) + 1;
    s.addText(String(idx), { x: 7.3, y: ny, w: 0.4, h: 0.4, fontFace: NUM, fontSize: 16, bold: true, color: C.gold, margin: 0 });
    s.addText(step, { x: 7.8, y: ny - 0.02, w: 4.7, h: 0.8, fontFace: CN, fontSize: 13.5, color: "C7D6E5", valign: "top", margin: 0, lineSpacingMultiple: 1.1 });
    ny += 0.95;
  });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 7.3, y: 5.55, w: 5.1, h: 0.55, rectRadius: 0.06, fill: { color: C.gold } });
  s.addText("延续驻场保障，共筑数据库稳定运维体系", { x: 7.3, y: 5.55, w: 5.1, h: 0.55, align: "center", valign: "middle", fontFace: CN, fontSize: 12.5, bold: true, color: C.deep, margin: 0 });
})();

// ---------- write ----------
const safeTitle = (title || "服务总结").replace(/[\\/:*?"<>|]/g, "_");
const outPath = OUT || path.resolve(safeTitle + ".pptx");
pres.writeFile({ fileName: outPath }).then(f => console.log("WROTE", f)).catch(e => { console.error("ERR", e); process.exit(1); });
