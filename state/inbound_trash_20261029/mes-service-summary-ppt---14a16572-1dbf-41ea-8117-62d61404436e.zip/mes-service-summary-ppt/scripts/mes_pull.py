#!/usr/bin/env python3
"""MES 全量报工拉取 + 聚合。

调用 `mes -o json statistics list --acc-id <id> --from <f> --to <t> --page-size 100 --page <n>`
分页拉取每个子项（accId）的全量报工，合并后输出 data.json。

注意：
- page-size 必须用 100（500 触发 HTTP/2 流错误）。
- 含所有 reviewStatus，不要用 statistics summary（只计已审批）。
- 需要公司 VPN 连通；未连 VPN 时 mes 命令会 server unreachable。
"""
import argparse
import json
import shutil
import subprocess
import sys
from datetime import date


def run_mes(args):
    """执行 mes 命令，返回解析后的 JSON dict；失败抛异常。"""
    if shutil.which("mes") is None:
        sys.exit("ERROR: 找不到 `mes` 命令，请先安装并登录 MES CLI（需公司 VPN）。")
    try:
        proc = subprocess.run(
            ["mes", "-o", "json"] + args,
            capture_output=True, text=True, timeout=120,
        )
    except subprocess.TimeoutExpired:
        sys.exit("ERROR: mes 命令超时（120s）。检查 VPN 是否连接。")
    if proc.returncode != 0:
        sys.exit(f"ERROR: mes 返回非零退出码 {proc.returncode}\n{proc.stderr.strip()}")
    out = (proc.stdout or "").strip()
    if not out:
        sys.exit(f"ERROR: mes 无输出。stderr={proc.stderr.strip()}")
    try:
        return json.loads(out)
    except json.JSONDecodeError as e:
        sys.exit(f"ERROR: mes 输出非 JSON：{e}\n前 200 字符：{out[:200]}")


def extract_list(obj):
    """从 mes 返回结构中抽取记录列表与分页信息。"""
    data = obj.get("data") if isinstance(obj, dict) else None
    if isinstance(data, dict):
        recs = data.get("list") or []
        pages = data.get("pages")
        return recs, pages
    if isinstance(obj, dict) and isinstance(obj.get("list"), list):
        return obj.get("list"), obj.get("pages")
    return [], None


def pull_acc_id(acc_id, from_d, to_d):
    """拉取单个 accId 的全量报工，返回记录列表。"""
    records = []
    page = 1
    total_pages = None
    while True:
        args = [
            "statistics", "list",
            "--acc-id", str(acc_id),
            "--from", from_d, "--to", to_d,
            "--page-size", "100", "--page", str(page),
        ]
        obj = run_mes(args)
        recs, pages = extract_list(obj)
        if pages is not None:
            total_pages = pages
        if not isinstance(recs, list):
            recs = []
        records.extend(recs)
        if total_pages is not None:
            if page >= int(total_pages):
                break
            page += 1
            continue
        # 未知总页数：以本页是否满 100 判断
        if len(recs) < 100:
            break
        page += 1
    return records


def slim(rec, acc_id):
    """只保留渲染所需字段，统一类型。"""
    return {
        "accId": acc_id,
        "executorName": rec.get("executorName") or rec.get("executorEmployeeName") or "未知",
        "taskTime": float(rec.get("taskTime") or 0),
        "start": (rec.get("start") or rec.get("startTime") or "")[:19],
        "remark": rec.get("remark") or "",
        "title": rec.get("title") or rec.get("taskName") or "",
        "reviewStatus": rec.get("reviewStatus"),
        "teamName": rec.get("teamName") or "",
    }


def main():
    ap = argparse.ArgumentParser(description="MES 全量报工拉取")
    ap.add_argument("--acc-ids", required=True, help="子项 accId，逗号分隔")
    ap.add_argument("--contract", default="", help="合同号（仅用于标注）")
    ap.add_argument("--from", dest="from_d", default="2010-01-01", help="起始日期 YYYY-MM-DD")
    ap.add_argument("--to", dest="to_d", default=date.today().isoformat(), help="截止日期 YYYY-MM-DD")
    ap.add_argument("--out", default="./data.json", help="输出 data.json 路径")
    args = ap.parse_args()

    acc_ids = [a.strip() for a in args.acc_ids.split(",") if a.strip()]
    if not acc_ids:
        sys.exit("ERROR: 至少提供一个 accId。")

    print(f"== 拉取 {len(acc_ids)} 个子项，区间 {args.from_d} ~ {args.to_d} ==")
    all_recs = []
    for aid in acc_ids:
        recs = pull_acc_id(aid, args.from_d, args.to_d)
        print(f"  accId {aid}: {len(recs)} 条")
        all_recs.extend(slim(r, aid) for r in recs)

    # 简单聚合摘要
    total_h = sum(r["taskTime"] for r in all_recs)
    people = len({r["executorName"] for r in all_recs})
    print(f"== 合并后：{len(all_recs)} 条，总工时 {total_h:.1f}h，{total_h/8:.1f} 人天，{people} 人 ==")

    out = {
        "meta": {
            "contract": args.contract,
            "accIds": acc_ids,
            "from": args.from_d,
            "to": args.to_d,
            "pulledAt": date.today().isoformat(),
        },
        "records": all_recs,
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"== 已写出 {args.out} ==")


if __name__ == "__main__":
    main()
