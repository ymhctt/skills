#!/usr/bin/env python3
"""抽取 .docx 服务内容文本（用于填写 meta.serviceScope）。

优先用 python-docx；未安装时回退到 zip + 正则解析 document.xml。
"""
import argparse
import os
import re
import sys
import zipfile


def via_python_docx(path):
    from docx import Document
    doc = Document(path)
    parts = []
    for p in doc.paragraphs:
        if p.text.strip():
            parts.append(p.text.strip())
    for tbl in doc.tables:
        for row in tbl.rows:
            cells = [c.text.strip() for c in row.cells if c.text.strip()]
            if cells:
                parts.append(" | ".join(cells))
    return "\n".join(parts)


def via_regex(path):
    with zipfile.ZipFile(path) as z:
        xml = z.read("word/document.xml").decode("utf-8", "ignore")
    # 段落
    paras = re.findall(r"<w:p[ >].*?</w:p>", xml, re.S)
    lines = []
    for p in paras:
        texts = re.findall(r"<w:t[^>]*>(.*?)</w:t>", p, re.S)
        line = "".join(texts).strip()
        if line:
            lines.append(line)
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="抽取 docx 文本")
    ap.add_argument("--in", dest="in_path", required=True, help="docx 路径")
    ap.add_argument("--out", default="", help="可选输出 txt 路径；缺省打印到 stdout")
    args = ap.parse_args()

    if not os.path.exists(args.in_path):
        sys.exit(f"ERROR: 文件不存在 {args.in_path}")

    text = ""
    try:
        text = via_python_docx(args.in_path)
    except ImportError:
        print("[info] python-docx 未安装，回退到 zip+正则解析", file=sys.stderr)
        text = via_regex(args.in_path)
    except Exception as e:
        print(f"[warn] python-docx 解析失败（{e}），回退正则", file=sys.stderr)
        text = via_regex(args.in_path)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"已写出 {args.out}（{len(text)} 字符）")
    else:
        print(text)


if __name__ == "__main__":
    main()
