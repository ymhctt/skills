#!/usr/bin/env python3
"""python-pptx 几何审计（替代 LibreOffice 视觉巡检）。

检查每页 shape：
- 出界（OOB）：x/w 超出画布 13.33 x 7.5（留 0.05 容差；封面/尾页出血装饰圆属真阴性，单独标注）。
- 文本溢出底边：估算文本行数 × 字号是否超过 shape 高度。
输出人类可读的问题清单与通过/失败结论。
"""
import argparse
import re
import sys

try:
    from pptx import Presentation
    from pptx.util import Emu
except ImportError:
    sys.exit("ERROR: 需要 python-pptx。请先 `pip install python-pptx`。")


PW = 13.33
PH = 7.5
TOL = 0.06


def emu_to_inch(v):
    return v / 914400.0 if v is not None else None


def estimate_lines(text, width_in, font_pt):
    if not text:
        return 0
    # CJK 字形 advance ≈ 1em = font_pt/72 inch；拉丁更窄，按 1em 是偏保守的过估，安全。
    char_w = max(0.05, font_pt / 72.0)
    chars_per_line = max(1, int(width_in / char_w))
    total = 0
    for line in text.split("\n"):
        total += max(1, -(-len(line) // chars_per_line))
    return total


def audit(path):
    prs = Presentation(path)
    issues = []
    for idx, slide in enumerate(prs.slides, start=1):
        for sh in slide.shapes:
            try:
                l = emu_to_inch(sh.left)
                t = emu_to_inch(sh.top)
                w = emu_to_inch(sh.width)
                h = emu_to_inch(sh.height)
            except Exception:
                continue
            if None in (l, t, w, h):
                continue
            right = l + w
            bottom = t + h
            # 出界
            if l < -TOL or t < -TOL or right > PW + TOL or bottom > PH + TOL:
                sev = "OOB"
                # 封面/尾页常见装饰圆：圆心在画布外、半径大、无文字
                is_deco = (w > 3.0 and h > 3.0 and not sh.has_text_frame)
                if is_deco:
                    sev = "OOB(deco-ok)"
                issues.append(f"  S{idx:02d} [{sev}] {sh.shape_type} @ "
                              f"x={l:.2f} y={t:.2f} w={w:.2f} h={h:.2f} "
                              f"(right={right:.2f} bottom={bottom:.2f})")
            # 文本溢出底边（仅对有文字的框）
            if sh.has_text_frame and sh.text_frame.text.strip():
                tf = sh.text_frame
                # 取最大字号：同时看 run 与 paragraph 级别（pptxgenjs 可能放在 pPr）
                max_pt = 12
                for p in tf.paragraphs:
                    if p.font and p.font.size:
                        max_pt = max(max_pt, p.font.size.pt)
                    for r in p.runs:
                        if r.font.size:
                            max_pt = max(max_pt, r.font.size.pt)
                lines = estimate_lines(tf.text, w - 0.1, max_pt)
                need = lines * max_pt * 1.2 / 72.0
                # 装饰性图标框（无中文且极短，多为 emoji）跳过
                has_cjk = bool(re.search(r"[一-鿿]", tf.text))
                if not has_cjk and len(tf.text.strip()) <= 3:
                    continue
                if need > h + 0.20:
                    issues.append(f"  S{idx:02d} [OVERFLOW] 文本约 {lines} 行/{need:.2f}in > 框高 {h:.2f}in "
                                  f"@ x={l:.2f} y={t:.2f} w={w:.2f} h={h:.2f}")

    print(f"== 审计 {path} | 画布 {PW}x{PH}in | 问题 {len(issues)} 项 ==")
    if issues:
        for i in issues:
            print(i)
    else:
        print("  未发现出界或文本溢出。")
    oob = [i for i in issues if "OOB(" not in i and i.strip().startswith("  S")]
    real = [i for i in oob if "OOB(deco-ok)" not in i]
    overflow = [i for i in issues if "[OVERFLOW]" in i]
    if real or overflow:
        print(f"\n结论：FAIL（{len(real)} 个真实出界 + {len(overflow)} 个文本溢出，需修复）")
        sys.exit(1)
    else:
        print("\n结论：PASS（装饰性出血忽略）")


def main():
    ap = argparse.ArgumentParser(description="PPTX 几何审计")
    ap.add_argument("pptx", help="待审计的 pptx 路径")
    args = ap.parse_args()
    audit(args.pptx)


if __name__ == "__main__":
    main()
